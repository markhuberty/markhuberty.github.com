-- these are very large Genentech families - about 4500 documents
-- FAMILY still growing.... Numbers can increase with previous releases
-- oct2011 : 5037 rows affected
-- april2011: 5015 rows affected
-- sept2010:  4922 rows affected

use patstatoct2011
go
select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind , e.publn_date
from 
  [tls201_appln] d
, [tls211_pat_publn] e
--, tls204_appln_prior f
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls219_inpadoc_fam] b
, [tls219_inpadoc_fam] c
where
a.publn_auth = 'AU'
and a.publn_nr = '     2003200585'
and a.publn_kind = 'B2'
and b.inpadoc_family_id = c.inpadoc_family_id 
and    b.appln_id = a.appln_id
   )
order by e.publn_date, e.publn_auth, e.publn_nr, e.publn_kind
;

select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind , e.publn_date
from 
  [tls201_appln] d
, [tls211_pat_publn] e
--, tls204_appln_prior f
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls219_inpadoc_fam] b
, [tls219_inpadoc_fam] c
where
 a.publn_auth = 'AT'
 and a.publn_nr = '         409225'
and a.publn_kind = 'T '
and b.inpadoc_family_id = c.inpadoc_family_id 
and    b.appln_id = a.appln_id
   )
order by e.publn_date, e.publn_auth, e.publn_nr, e.publn_kind
;

use patstatapril2011 
go
select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind , e.publn_date
from 
  [tls201_appln] d
, [tls211_pat_publn] e
--, tls204_appln_prior f
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls219_inpadoc_fam] b
, [tls219_inpadoc_fam] c
where
a.publn_auth = 'AU'
and a.publn_nr = '     2003200585'
and a.publn_kind = 'B2'
and b.inpadoc_family_id = c.inpadoc_family_id 
and    b.appln_id = a.appln_id
   )
order by e.publn_date, e.publn_auth, e.publn_nr, e.publn_kind
;

select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind , e.publn_date
from 
  [tls201_appln] d
, [tls211_pat_publn] e
--, tls204_appln_prior f
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls219_inpadoc_fam] b
, [tls219_inpadoc_fam] c
where
 a.publn_auth = 'AT'
 and a.publn_nr = '         409225'
and a.publn_kind = 'T '
and b.inpadoc_family_id = c.inpadoc_family_id 
and    b.appln_id = a.appln_id
   )
order by e.publn_date, e.publn_auth, e.publn_nr, e.publn_kind
;
