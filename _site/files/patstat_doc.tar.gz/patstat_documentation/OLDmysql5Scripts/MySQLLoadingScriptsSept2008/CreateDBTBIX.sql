-- This script creates a MySQL database named patstatrequest
-- by defining a new set of tables and indexes.  
--
-- If you want to keep older patstat extract versions, 
-- you should rename them. 
--
-- Version March2008    Created by Tony Teculescu    on 04/03/2008    
--

CREATE DATABASE `patstatSept2008` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `patstatSept2008`;

--
-- Table `tls201_appln`
--

CREATE TABLE  `tls201_appln` (
  
`appln_id` int(10) NOT NULL default '0',
  
`appln_auth` char(2) NOT NULL default '',
  
`appln_nr` char(15) NOT NULL default '',
  
`appln_kind` char(2) NOT NULL default '00',
  
`appln_filing_date` date default NULL,
  
`ipr_type` char(2) NOT NULL default '',
  
`appln_title_lg` char(2) NOT NULL default '',
  
`appln_abstract_lg` char(2) NOT NULL default '',
  
`internat_appln_id` int(10) NOT NULL default '0',
  
PRIMARY KEY  (`appln_id`),
  
KEY `internat_appln_id` (`internat_appln_id`),
  
KEY `appln_auth` (`appln_auth`,`appln_nr`,`appln_kind`),
  
KEY `appln_filing_date` (`appln_filing_date`)
) 
ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls202_appln_title`
-- 

CREATE TABLE `tls202_appln_title` (
  appln_id int(10) NOT NULL default '0',
  appln_title text NOT NULL,
  PRIMARY KEY  (appln_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls203_appln_abstr`
--

CREATE TABLE `tls203_appln_abstr` (
  appln_id int(10) NOT NULL default '0',
  appln_abstract text NOT NULL,
  PRIMARY KEY  (appln_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls204_appln_prior`
-- 

CREATE TABLE `tls204_appln_prior` (
  appln_id int(10) NOT NULL default '0',
  prior_appln_id int(10) NOT NULL default '0',
  prior_appln_seq_nr smallint(4) NOT NULL default '0',
  PRIMARY KEY  (appln_id,prior_appln_id),
  INDEX (prior_appln_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls205_tech_rel`
-- 

CREATE TABLE `tls205_tech_rel` (
  appln_id int(10) NOT NULL default '0',
  tech_rel_appln_id int(10) NOT NULL default '0',
  PRIMARY KEY  (appln_id,tech_rel_appln_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls206_person`
-- 

CREATE TABLE `tls206_person` (
  person_id int(10) NOT NULL default '0',
  person_ctry_code varchar(2) NOT NULL default '',
  doc_std_name_id int(10) NOT NULL default '0',
  person_name text NOT NULL,
  person_address text NOT NULL,
  PRIMARY KEY  (person_id),
  INDEX (person_ctry_code)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls207_pers_appln`
-- 

CREATE TABLE `tls207_pers_appln` (
  person_id int(10) NOT NULL default '0',
  appln_id int(10) NOT NULL default '0',
  applt_seq_nr smallint(4) NOT NULL default '0',
  invt_seq_nr smallint(4) NOT NULL default '0',
  PRIMARY KEY  (person_id,appln_id),
  INDEX (person_id),
  INDEX (appln_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls208_doc_std_nms`
-- 

CREATE TABLE `tls208_doc_std_nms` (
  doc_std_name_id int(10) NOT NULL default '0',
  doc_std_name char(30) NOT NULL default '',
  PRIMARY KEY  (doc_std_name_id),
  INDEX (doc_std_name)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls209_appln_ipc`
-- 

CREATE TABLE  `tls209_appln_ipc` (
  
`appln_id` int(10) NOT NULL default '0',
  
`ipc_class_symbol` char(15) NOT NULL default '',
  
`ipc_class_level` char(1) NOT NULL default '',
  
`ipc_version` date default NULL,
  
`ipc_value` char(1) NOT NULL default '',
  
`ipc_position` char(1) NOT NULL default '',
  
`ipc_gener_auth` char(2) NOT NULL default '',
  
PRIMARY KEY  (`appln_id`,`ipc_class_symbol`,`ipc_class_level`),
  
KEY `ipc_class_symbol` (`ipc_class_symbol`)
) 
ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls210_appln_n_cls`
-- 

CREATE TABLE `tls210_appln_n_cls` (
  appln_id int(10) NOT NULL default '0',
  nat_class_symbol char(15) NOT NULL default '',
  PRIMARY KEY  (appln_id,nat_class_symbol)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls211_pat_publn`
-- 

CREATE TABLE  `tls211_pat_publn` (
  
`pat_publn_id` int(10) NOT NULL default '0',
  
`publn_auth` char(2) NOT NULL default '',
  
`publn_nr` char(15) NOT NULL default '',
  
`publn_kind` char(2) NOT NULL default '',
  
`appln_id` int(10) NOT NULL default '0',
  
`publn_date` date default NULL,
  
`publn_lg` char(2) NOT NULL default '',
  
PRIMARY KEY  (`pat_publn_id`),
  
KEY `publn_auth` (`publn_auth`,`publn_nr`,`publn_kind`),
  
KEY `appln_id` (`appln_id`),
  
KEY `publn_date` (`publn_date`)
) 
ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls212_citation`
-- 

CREATE TABLE `tls212_citation` (
  pat_publn_id int(10) NOT NULL default '0',
  citn_id smallint(4) NOT NULL default '0',
  cited_pat_publn_id int(10) NOT NULL default '0',
  npl_publn_id int(10) NOT NULL default '0',
  pat_citn_seq_nr smallint(4) NOT NULL default '0',
  npl_citn_seq_nr smallint(4) NOT NULL default '0',
  citn_origin char(5) NOT NULL default '',
  PRIMARY KEY  (pat_publn_id, citn_id),
  INDEX (cited_pat_publn_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0;

-- -----------------------------------------------------------

-- 
-- Table `tls214_npl_publn`
-- 

CREATE TABLE `tls214_npl_publn` (
  npl_publn_id int(10) NOT NULL default '0',
  npl_biblio text NOT NULL,
  PRIMARY KEY  (npl_publn_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls215_citn_categ`
-- 

CREATE TABLE `tls215_citn_categ` (
  pat_publn_id int(10) NOT NULL default '0',
  citn_id smallint(4) NOT NULL default '0',
  citn_categ char(1) NOT NULL default '',
  PRIMARY KEY  (pat_publn_id,citn_id,citn_categ)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls216_appln_contn`
-- 

CREATE TABLE `tls216_appln_contn` (
  appln_id int(10) NOT NULL default '0',
  parent_appln_id int(10) NOT NULL default '0',
  contn_type char(3) NOT NULL default '',
  PRIMARY KEY  (appln_id,parent_appln_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------------------------------------
-- 
-- Table `tls217_appln_i_cls`
-- 

CREATE TABLE `tls217_appln_i_cls` (
  appln_id int(10) NOT NULL default '0',
  ico_class_symbol char(15) NOT NULL default '',
  PRIMARY KEY  (appln_id,ico_class_symbol)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------------------------------------
-- 
-- Table `tls218_docdb_fam`
-- 

CREATE TABLE `tls218_docdb_fam` (
  appln_id int(10) NOT NULL default '0',
  docdb_family_id int(10) NOT NULL default '0',
  PRIMARY KEY  (appln_id,docdb_family_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------------------------------------

-- 
-- Table `tls219_inpadoc_fam`
-- 

CREATE TABLE `tls219_inpadoc_fam` (
  appln_id int(10) NOT NULL default '0',
  inpadoc_family_id int(10) NOT NULL default '0',
  PRIMARY KEY  (appln_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



