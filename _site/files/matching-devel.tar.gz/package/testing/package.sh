#!/bin/bash

rm matching-devel.tar.gz
mkdir ~/package
cp -r ../Matching ~/package
cp -r ../testing ~/package
rm ~/package/*.R
tar -zcvf matching-devel.tar.gz -C ~/ ./package
rm -r ~/package

