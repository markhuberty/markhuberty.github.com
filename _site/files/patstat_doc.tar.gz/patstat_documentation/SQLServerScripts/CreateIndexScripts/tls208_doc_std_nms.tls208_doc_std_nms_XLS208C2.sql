USE [patstatoct2011]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tls208_doc_std_nms]') AND name = N'tls208_doc_std_nms_XLS208C2')
DROP INDEX [tls208_doc_std_nms_XLS208C2] ON [dbo].[tls208_doc_std_nms] WITH ( ONLINE = OFF )
GO

CREATE NONCLUSTERED INDEX [tls208_doc_std_nms_XLS208C2] ON [dbo].[tls208_doc_std_nms] 
(
	[doc_std_name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]
GO

