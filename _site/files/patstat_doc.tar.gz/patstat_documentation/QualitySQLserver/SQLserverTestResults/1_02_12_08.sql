-- Query to check that number of "granted" publications has not gone down.
-- Needs to be checked -> corrections ?

/* authority	Grantedpublications		authority	Grantedpublications		ok or not
IE	70338		IE	70464		not ok
MY	8973		MY	9620		not ok
RO	49426		RO	60162		not ok */



Use patstatoct2011
go
SELECT tls211_pat_publn.publn_auth as authority, Count(tls211_pat_publn.pat_publn_id) AS Grantedpublications_patstatoct2011
FROM tls211_pat_publn
where tls211_pat_publn.publn_first_grant=1
and YEAR(publn_date) < '9999'
GROUP BY tls211_pat_publn.publn_auth
ORDER BY tls211_pat_publn.publn_auth;


Use patstatapril2011
go
SELECT tls211_pat_publn.publn_auth as authority, Count(tls211_pat_publn.pat_publn_id) AS Grantedpublications_patstatapril2011
FROM tls211_pat_publn
where tls211_pat_publn.publn_first_grant=1
and YEAR(publn_date) < '9999'
GROUP BY tls211_pat_publn.publn_auth
ORDER BY tls211_pat_publn.publn_auth;
