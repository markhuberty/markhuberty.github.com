-- This runs a set of scripts to load a database table
--
--
-- Version March2008    Created by Tony Teculescu    on 04/03/2008    
--


load data local infile '<enter path of unzipped files here>\\tls216_part01.txt' into table TLS216_APPLN_CONTN fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
