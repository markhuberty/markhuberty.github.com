use patstatoct2011
go
select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind 
from 
  [tls201_appln] d
, [tls211_pat_publn] e
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls219_inpadoc_fam] b
, [tls219_inpadoc_fam] c
where
   a.publn_auth = 'EP'
--and a.publn_nr = '        1000000'
and a.publn_nr = '        1592083' -- jouve had this as a pct not a div
--and a.publn_kind = 'A1'
and b.inpadoc_family_id = c.inpadoc_family_id 
and    b.appln_id = a.appln_id
   )

order by e.publn_auth, e.publn_nr, e.publn_kind
;
use patstatapril2011 
go
select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind 
from 
  [tls201_appln] d
, [tls211_pat_publn] e
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls219_inpadoc_fam] b
, [tls219_inpadoc_fam] c
where
   a.publn_auth = 'EP'
--and a.publn_nr = '        1000000'
and a.publn_nr = '        1592083' -- jouve had this as a pct not a div
--and a.publn_kind = 'A1'
and b.inpadoc_family_id = c.inpadoc_family_id 
and    b.appln_id = a.appln_id
   )

order by e.publn_auth, e.publn_nr, e.publn_kind
;
