--0059-display-ICO-symbols
-- include at least 3 different publications
--compare against Y02 from  patstatapril2011


use patstatoct2011 
go

SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
    b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'EP'
  and publn_nr = '        2301097' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        2302694' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        2270914' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        2246906' )
or 
   (publn_auth = 'EP'
  and publn_nr = '        2187467' )
or 
   (publn_auth = 'EP'
  and publn_nr = '        2138400' )
or 
   (publn_auth = 'EP'
  and publn_nr = '        2131427' )
  )

  and  a.appln_id = b.appln_id
   and epo_class_scheme = 'ICO'
   and epo_class_symbol like 'Y%'

  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol;
GO

use patstatapril2011 
go

SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
    b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'EP'
  and publn_nr = '        2301097' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        2302694' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        2270914' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        2246906' )
or 
   (publn_auth = 'EP'
  and publn_nr = '        2187467' )
or 
   (publn_auth = 'EP'
  and publn_nr = '        2138400' )
or 
   (publn_auth = 'EP'
  and publn_nr = '        2131427' )
  )

  and  a.appln_id = b.appln_id
   and epo_class_scheme = 'ICO'
   and epo_class_symbol like 'Y%'

  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol;
GO

