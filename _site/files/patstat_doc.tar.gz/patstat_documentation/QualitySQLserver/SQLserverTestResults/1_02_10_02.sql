--note that this was a very late bug in the jouve version of patstatapril2011,
-- returning only 21 members. This was fixed , but jouve did not update the september version
-- as we checked it in the april 2010 version.

use patstatoct2011 
go
select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind , e.publn_date
from 
  [tls201_appln] d
, [tls211_pat_publn] e
--, tls204_appln_prior f
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls219_inpadoc_fam] b
, [tls219_inpadoc_fam] c
where
--this JP number will first appear in April 2010 edition
--and a.publn_auth = 'JP'
  --and a.publn_nr = '        4331595'
  --and b.publn_kind = 'B2'
 a.publn_auth = 'BR'
  and a.publn_nr = '        0211565'
and a.publn_kind = 'A '
and b.inpadoc_family_id = c.inpadoc_family_id 
and    b.appln_id = a.appln_id
   )

order by e.publn_auth, e.publn_nr, e.publn_kind
;
use patstatapril2011
go
select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind , e.publn_date
from 
  [tls201_appln] d
, [tls211_pat_publn] e
--, tls204_appln_prior f
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls219_inpadoc_fam] b
, [tls219_inpadoc_fam] c
where
--this JP number will first appear in April 2010 edition
--and a.publn_auth = 'JP'
  --and a.publn_nr = '        4331595'
  --and b.publn_kind = 'B2'
 a.publn_auth = 'BR'
  and a.publn_nr = '        0211565'
and a.publn_kind = 'A '
and b.inpadoc_family_id = c.inpadoc_family_id 
and    b.appln_id = a.appln_id
   )

order by e.publn_auth, e.publn_nr, e.publn_kind
;
