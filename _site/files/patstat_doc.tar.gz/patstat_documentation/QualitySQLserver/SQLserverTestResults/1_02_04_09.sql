-- modify pat_publn_id for a recent EP publication with following query
--
-- SELECT TOP 1000 [pat_publn_id]
--      ,[publn_auth]
--      ,[publn_nr]
--      ,[publn_kind]
--      ,[appln_id]
--     ,[publn_date]
--      ,[publn_lg]
--      ,[publn_first_grant]
--      ,[publn_claims]
--  FROM [patstatoct2011].[dbo].[tls211_pat_publn]
--  where publn_auth = 'EP' and year(publn_date) < '9999'
--  order by publn_date desc 

-- sept2010:  entered following publn_id: 
-- purpose of test is to check names agains DocStandard Names (Blanks is possible)



use patstatoct2011
go
     SELECT
       A.APPLN_ID
     , B.PERSON_ID
     , B.DOC_STD_NAME_ID
     , C.APPLT_SEQ_NR AS APP
     , C.INVT_SEQ_NR AS INV
     , e.PAT_PUBLN_ID AS PubID
     , e.publn_auth as PubCC
     , e.publn_nr   as PubNR
     , e.publn_kind as PubKD
     , SUBSTRING(B.PERSON_NAME,1,25) AS PersonNAMEtruncated
     , B.PERSON_ADDRESS
     , SUBSTRING(D.DOC_STD_NAME,1,25) AS DocStandardNAME
     , B.PERSON_CTRY_CODE
            FROM [tls201_APPLN  ]     A
            ,    [tls206_PERSON ]     B
            ,    [tls207_PERS_APPLN ] C
            ,    [tls208_DOC_STD_NMS ] D
            ,    [tls211_pat_publn ]   E
     WHERE
  --
     A.APPLN_AUTH     in ('EP')
     -- get a new pat_publn_id ie EP	        2079300	A2
     -- pat_publn_id = 19179891 
     -- AND e.PAT_PUBLN_ID           in (19724439,18209872,18221982,22086099 )
     -- AND e.PAT_PUBLN_ID           in (20081817,20090279,20244923,20233593) 
     -- AND e.PAT_PUBLN_ID           in (74438957,74438956,74438955,74438954, 73254447) 
     and e.pat_publn_ID in (77101310,76395649,76363372,76363371,76356355)
     AND A.APPLN_ID  = C.APPLN_ID
     AND A.APPLN_ID  = e.APPLN_ID
     AND C.PERSON_ID = B.PERSON_ID
     AND B.DOC_STD_NAME_ID =D.DOC_STD_NAME_ID
     ORDER BY  PersonNAMEtruncated
             , A.APPLN_ID
             , C.INVT_SEQ_NR
             , C.APPLT_SEQ_NR
             ;
     