use patstatoct2011
go
select person_id,appln_id,nbr=COUNT(*)
from tls207_pers_appln
group by person_id,appln_id
having COUNT(*)>1
order by nbr desc;

use patstatapril2011
go
select person_id,appln_id,nbr=COUNT(*)
from tls207_pers_appln
group by person_id,appln_id
having COUNT(*)>1
order by nbr desc
