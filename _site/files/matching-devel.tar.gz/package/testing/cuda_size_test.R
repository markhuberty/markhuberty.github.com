## Mark Huberty
## 6 June 2010
## Code to test the new GenMatch function
library(Matching,
        #lib.loc="~/library/",
        lib.loc="library",
        verbose=TRUE
        )
## Bring in the data
data(lalonde)

rowcount <- dim(lalonde)[1]

lalonde <- lalonde[c(1:50, (rowcount-51):rowcount),]


lalonde2 <- rbind(lalonde, lalonde)
lalonde3 <- rbind(lalonde, lalonde, lalonde)
lalonde4 <- rbind(lalonde2, lalonde2)
lalonde5 <- rbind(lalonde2, lalonde3)
lalonde6 <- rbind(lalonde3, lalonde3)

lalonde.list <- list(lalonde, lalonde2, lalonde3, lalonde4, lalonde5, lalonde6)

##set.seed(500)
#vec <- sample(1:dim(lalonde)[1], 100, replace=TRUE)
#lalonde.short <- lalonde[vec,]
#attach(lalonde.list)


N <- 300
lapply(1:N, function(y){
#The covariates we want to match on
  print(paste("Lalonde dataset no. ", y))
  data <- as.data.frame(lalonde.list[[y]])
  attach(data)
  X = cbind(age, educ, black, hisp, married, nodegr, u74, u75, re75, re74);
  seed <- 38212
  pl <- 0

  ## Benchmarking
  N <- 50
  seed <- 1254

  print("Starting timing for beta=FALSE")
  genout.old.timing <- sapply(1:N, function(x){ 
    print(paste("Run ", x, " for lalonde set ", y))
    set.seed(seed)
    out <- system.time(GenMatch(Tr=treat,
                                X=X,
                                gpu=FALSE,
                                ties=TRUE,
                                unif.seed=seed,
                                print.level=pl
                                )
                       )
    return(out)
    
  }
                              )           

  #save(genout.old.timing, file=paste("genout.old.timing", y, ".RData", sep=""))

  print("Starting timing for beta=TRUE")
  

  genout.new.timing <- sapply(1:N, function(x){
    
    set.seed(seed)
    out <- system.time(GenMatch(Tr=treat,
                                X=X,
                                gpu=TRUE,
                                ties=TRUE,
                                unif.seed=seed,
                                print.level=pl
                                )
                       )
    
    return(out)
  }
                              )

  detach(data)
  save(genout.old.timing, genout.new.timing, file=paste("genout", y, ".RData", sep=""))
     }
  )

save.image("matching-devel-timing.RData")
