-- check if NPL documents are in the list
-- after test, change for a recent publication number that has XP documents use following code to find some ep documents with at least 5 NPL's citations


/*
			use patstatoct2011
			go
			SELECT TOP 10 
				  [publn_auth]
				  ,[publn_nr]
				  ,[publn_kind]
				  ,[appln_id]
				  ,[publn_date]
				  ,[publn_lg]
				  ,[publn_first_grant]
				  ,[publn_claims]
				  ,b.*
				  ,c.*
			  FROM tls211_pat_publn a join tls212_citation b on a.pat_publn_id = b.pat_publn_id
			  join tls214_npl_publn c on b.npl_publn_id = c.npl_publn_id
			  where npl_citn_seq_nr = 5
			  order by publn_date desc
*/
use patstatoct2011
go

SELECT  *
     FROM [TLS212_CITATION]  A
   ,     [TLS211_PAT_PUBLN] B
   ,     [TLS214_NPL_PUBLN] C
   WHERE
     A.PAT_PUBLN_ID = B.PAT_PUBLN_ID
     AND A.NPL_PUBLN_ID = C.NPL_PUBLN_ID
     AND ((B.PUBLN_AUTH = 'EP' AND B.PUBLN_NR = '        2348120') or (B.PUBLN_AUTH = 'FR' AND B.PUBLN_NR = '        2955707'))
   ORDER BY Publn_auth, publn_nr, CITN_ID , NPL_CITN_SEQ_NR ;

use patstatapril2011
go

SELECT  *
     FROM [TLS212_CITATION]  A
   ,     [TLS211_PAT_PUBLN] B
   ,     [TLS214_NPL_PUBLN] C
    WHERE
     A.PAT_PUBLN_ID = B.PAT_PUBLN_ID
     AND A.NPL_PUBLN_ID = C.NPL_PUBLN_ID
     AND ((B.PUBLN_AUTH = 'EP' AND B.PUBLN_NR = '        2348120') or (B.PUBLN_AUTH = 'FR' AND B.PUBLN_NR = '        2955707'))
   ORDER BY Publn_auth, publn_nr,CITN_ID , NPL_CITN_SEQ_NR ;

