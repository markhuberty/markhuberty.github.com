--0058-display-ECNO-symbols
-- include at least 3 different publications
-- Compare against GPI result or DACC
-- Slightly corrected and changed script to include count Y02 tags

use patstatoct2011 
go

SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'GB'
  and publn_nr = '        0426811' )
  or 
   (publn_auth = 'GB'
  and publn_nr = '        0426836' )
  or 
   (publn_auth = 'GB'
  and publn_nr = '        2432313' )
  or 
   (publn_auth = 'ES'
  and publn_nr = '        1049349' )
  or 
   (publn_auth = 'ES'
  and publn_nr = '        2181513' )
  )
  and  a.appln_id = b.appln_id
   --and epo_class_scheme = 'ECNO'

  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol;


SELECT count(*)

  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
   a.appln_id = b.appln_id
   and (epo_class_symbol like 'Y01N%' or epo_class_symbol like 'Y02%');


SELECT epo_class_symbol, count(*)

  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
   a.appln_id = b.appln_id
   and (epo_class_symbol like 'Y02%' or epo_class_symbol like 'Y01%')
   group by epo_class_symbol
order by epo_class_symbol;



use patstatapril2011 
go

SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'GB'
  and publn_nr = '        0426811' )
  or 
   (publn_auth = 'GB'
  and publn_nr = '        0426836' )
  or 
   (publn_auth = 'GB'
  and publn_nr = '        2432313' )
  or 
   (publn_auth = 'ES'
  and publn_nr = '        1049349' )
  or 
   (publn_auth = 'ES'
  and publn_nr = '        2181513' )
  )
  and  a.appln_id = b.appln_id
   --and epo_class_scheme = 'ECNO'

  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol;

SELECT count(*)

  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
   a.appln_id = b.appln_id
   and (epo_class_symbol like 'Y01N%' or epo_class_symbol like 'Y02%');

SELECT epo_class_symbol, count(*)

  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
   a.appln_id = b.appln_id
   and (epo_class_symbol like 'Y02%' or epo_class_symbol like 'Y01%')
   group by epo_class_symbol
order by epo_class_symbol;