-- Check if abstracts for current year are available for JP, EP, US and WO publication.
-- Abstracts should be available for the 4 authorities and the publication date should be around cut-of date for production. (July - January)

use patstatoct2011
go
  SELECT TOP 5 
     publn_auth, publn_nr, publn_kind
      ,publn_date
      ,appln_abstract
  FROM tls203_appln_abstr join tls211_pat_publn on tls203_appln_abstr.appln_id = tls211_pat_publn.appln_id
  where publn_auth = 'JP' and year(publn_date) = year(GETDATE())
  order by publn_date desc
  
  SELECT TOP 5 
     publn_auth, publn_nr, publn_kind
      ,publn_date
      ,appln_abstract
  FROM tls203_appln_abstr join tls211_pat_publn on tls203_appln_abstr.appln_id = tls211_pat_publn.appln_id
  where publn_auth = 'us'and year(publn_date) = year(GETDATE())
  order by publn_date desc
  
  SELECT TOP 5 
     publn_auth, publn_nr, publn_kind
      ,publn_date
      ,appln_abstract
  FROM tls203_appln_abstr join tls211_pat_publn on tls203_appln_abstr.appln_id = tls211_pat_publn.appln_id
  where publn_auth = 'wo'and year(publn_date) = year(GETDATE())
  order by publn_date desc
  
  SELECT TOP 5 
     publn_auth, publn_nr, publn_kind
      ,publn_date
      ,appln_abstract
  FROM tls203_appln_abstr join tls211_pat_publn on tls203_appln_abstr.appln_id = tls211_pat_publn.appln_id
  where publn_auth = 'ep'and year(publn_date) = year(GETDATE())
  order by publn_date desc
  
  use patstatapril2011
  go
  SELECT TOP 5 
     publn_auth, publn_nr, publn_kind
      ,publn_date
      ,appln_abstract
  FROM tls203_appln_abstr join tls211_pat_publn on tls203_appln_abstr.appln_id = tls211_pat_publn.appln_id
  where publn_auth = 'JP' and year(publn_date) = year(GETDATE())
  order by publn_date desc
  
  SELECT TOP 5 
     publn_auth, publn_nr, publn_kind
      ,publn_date
      ,appln_abstract
  FROM tls203_appln_abstr join tls211_pat_publn on tls203_appln_abstr.appln_id = tls211_pat_publn.appln_id
  where publn_auth = 'us'and year(publn_date) = year(GETDATE())
  order by publn_date desc
  
  SELECT TOP 5 
     publn_auth, publn_nr, publn_kind
      ,publn_date
      ,appln_abstract
  FROM tls203_appln_abstr join tls211_pat_publn on tls203_appln_abstr.appln_id = tls211_pat_publn.appln_id
  where publn_auth = 'wo'and year(publn_date) = year(GETDATE())
  order by publn_date desc
  
  SELECT TOP 5 
     publn_auth, publn_nr, publn_kind
      ,publn_date
      ,appln_abstract
  FROM tls203_appln_abstr join tls211_pat_publn on tls203_appln_abstr.appln_id = tls211_pat_publn.appln_id
  where publn_auth = 'ep'and year(publn_date) = year(GETDATE())
  order by publn_date desc