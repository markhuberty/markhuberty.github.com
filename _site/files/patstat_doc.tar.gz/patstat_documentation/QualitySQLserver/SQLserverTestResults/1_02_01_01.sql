-- Changed the order by field to a.appln_nr because the 2011 version had changed the appln_title field to ntext -> no order by possible

use patstatoct2011
go
  SELECT a.appln_id, appln_title, a.appln_auth, a.appln_nr
   FROM
   [TLS201_APPLN ] a
  ,[TLS202_APPLN_title ] b
     where appln_title like '%FOOD%'
     and a.appln_id = b.appln_id
     and a.appln_filing_date between '2002-01-15' and '2002-01-31'
	order by (a.appln_nr)
   ;
 
use patstatapril2011
go
  SELECT a.appln_id, appln_title, a.appln_auth, a.appln_nr
   FROM
   [TLS201_APPLN ] a
  ,[TLS202_APPLN_title ] b
     where appln_title like '%FOOD%'
     and a.appln_id = b.appln_id
     and a.appln_filing_date between '2002-01-15' and '2002-01-31'
 order by (a.appln_nr)
   ;
 
