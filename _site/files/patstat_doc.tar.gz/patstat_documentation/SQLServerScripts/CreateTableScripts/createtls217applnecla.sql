USE [patstatoct2011]
GO

/****** Object:  Table [dbo].[tls217_appln_ecla]    Script Date: 07/06/2009 04:32:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tls217_appln_ecla](
	[appln_id] [int] NOT NULL,
	[epo_class_auth] [nchar](2) NOT NULL,
	[epo_class_scheme] [nchar](4) NOT NULL,
	[epo_class_symbol] [nchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[appln_id] ASC,
	[epo_class_auth] ASC,
	[epo_class_scheme] ASC,
	[epo_class_symbol] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = ON, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[tls217_appln_ecla] ADD  DEFAULT ('0') FOR [appln_id]
GO


