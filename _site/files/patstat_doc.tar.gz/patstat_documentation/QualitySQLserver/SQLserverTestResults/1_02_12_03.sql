-- This test gives a row for each publication authority with the corresponging number of publications that have been marked as first granted
-- Test result:  in  principle the numbers should never do down for any given authority compared to previous release.
-- Quick double check for EP, DE, US in GPI: PUC = "ep" and ISG="y"
-- Total run time: 02:30 minutes (Result compared to APRIL not so good, probably xsl sheet codes not ok, CYPRUS for September probably wrong.


Use patstatoct2011
go
SELECT tls211_pat_publn.publn_auth as authority, Count(tls211_pat_publn.pat_publn_id) AS Grantedpublications
FROM tls211_pat_publn
where tls211_pat_publn.publn_first_grant=1
and YEAR(publn_date) < '9999'
GROUP BY tls211_pat_publn.publn_auth
ORDER BY tls211_pat_publn.publn_auth;


Use patstatapril2011
go
SELECT tls211_pat_publn.publn_auth as authority, Count(tls211_pat_publn.pat_publn_id) AS Grantedpublications
FROM tls211_pat_publn
where tls211_pat_publn.publn_first_grant=1
and YEAR(publn_date) < '9999'
GROUP BY tls211_pat_publn.publn_auth
ORDER BY tls211_pat_publn.publn_auth;