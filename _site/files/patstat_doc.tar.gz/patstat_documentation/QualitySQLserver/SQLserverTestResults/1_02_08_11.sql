--0056-display-IDT-symbols
-- should not be any IDT symbols after about 1980 ??

-- Compare against GPI result or DACC
-- I rewrote query to make it appln_id independant


use patstatoct2011 
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  year(b.publn_date ) = '2011'
  and  a.appln_id = b.appln_id
  and  epo_class_scheme = 'IDT'
-- strange to see such recent IDT classifications..
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
      ;


use patstatapril2011 
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  year(b.publn_date ) = '2011'
  and  a.appln_id = b.appln_id
  and  epo_class_scheme = 'IDT'
-- strange to see such recent IDT classifications..
   order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
      ;

