--Count EP publications -applications because of link appln_id- that do not have an ECLA classification
-- GPI result 1869707;
-- GPI Search: PUC = "EP" and (PUK = "A1" or PUK="A3") and ECLA = "*"


use patstatoct2011
go
--count(distinct (pat_publn_id)) without ECLA
--count publications 
SELECT year(b.publn_date),'EP Publications without ECLA Count:' , count(*)

from    tls211_pat_publn b

where

      b.appln_id not in (
							select distinct a.appln_id 
							FROM tls217_APPLN_ECLA   a 
							where  epo_class_scheme = 'EC')
	  and b.publn_auth = 'EP'

group by year(b.publn_date)
order by year(b.publn_date)
;



use patstatoct2011
go
--count(distinct (pat_publn_id)) 
--count publications 
SELECT year(b.publn_date),'EP Publications with ECLA Count:' , count(*)

from    tls211_pat_publn b

where

      b.appln_id in (
							select distinct a.appln_id 
							FROM tls217_APPLN_ECLA   a 
							where  epo_class_scheme = 'EC')
	  and b.publn_auth = 'EP'

group by year(b.publn_date)
order by year(b.publn_date)
;


use patstatoct2011
go
--count(distinct (pat_publn_id)) 
--count publications 
SELECT 'EP Publications with ECLA total Count:' , count(*)

from    tls211_pat_publn b

where

      b.appln_id in (
							select distinct a.appln_id 
							FROM tls217_APPLN_ECLA   a 
							where  epo_class_scheme = 'EC')
	  and b.publn_auth = 'EP'

;
use patstatapril2011
go
--count(distinct (pat_publn_id)) without ECLA
--count publications 
SELECT year(b.publn_date),'EP Publications without ECLA Count:' , count(*)

from    tls211_pat_publn b

where

      b.appln_id not in (
							select distinct a.appln_id 
							FROM tls217_APPLN_ECLA   a 
							where  epo_class_scheme = 'EC')
	  and b.publn_auth = 'EP'

group by year(b.publn_date)
order by year(b.publn_date)
;



use patstatapril2011
go
--count(distinct (pat_publn_id)) 
--count publications 
SELECT year(b.publn_date),'EP Publications with ECLA Count:' , count(*)

from    tls211_pat_publn b

where

      b.appln_id in (
							select distinct a.appln_id 
							FROM tls217_APPLN_ECLA   a 
							where  epo_class_scheme = 'EC')
	  and b.publn_auth = 'EP'

group by year(b.publn_date)
order by year(b.publn_date)
;


use patstatapril2011
go
--count(distinct (pat_publn_id)) 
--count publications 
SELECT 'EP Publications with ECLA total Count:' , count(*)

from    tls211_pat_publn b

where

      b.appln_id in (
							select distinct a.appln_id 
							FROM tls217_APPLN_ECLA   a 
							where  epo_class_scheme = 'EC')
	  and b.publn_auth = 'EP'

;
