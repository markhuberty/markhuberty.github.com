Readme for MySQL load scripts

This document explains the steps to load the EPO Worldwide Patent Statistical Database in a MySQL database. 

Prerequisites: 
Hardware
We suggest a powerful platform, if possible multi-processor with minimum 140GB, (some people use 300GB) free space on hard drive.
Buy as much internal RAM as you can afford ( more than 8GB).

Software
Currently we only know about people using the Windows platform (NT, XP or Vista).
MySQL Enterprise or the free MySQL Community Server version 5.0 along which we recommend also
installing at least the GUI Tools. More people use the MYISAM engine than the INNODB , but MYISAM is very slow 
at loading and indexing on a small server - MYISAM needs more than 8GB internal RAM.


Please follow the following steps to instal the data:

1. Edit the CreateDBTBIX.cmd file in this directory to set the necessary parameters for running the mysql 
executable (path, hostname, userid).

2. Run the CreateDBTBIX.cmd file (by double-clicking it) and enter the password (if any) when requested. 
The scripts will create a brand new database named patstatSept2008 and its schema for you, using
CreateDBTBIXreport.txt as a log file.

3. Edit each loadTableTlsxxxxx.cmd file to set the necessary parameters for running the mysql 
executable (path, hostname, userid) and each loadTableTlsxxxxx.sql file to enter the proper file path.

4. Run each loadTableTlsxxxxx.cmd file and check out each report file for errors.

Now your patstatSept2008 database is ready to use.


Should you encounter any installation problem or should you have additional questions, please don�t hesitate to 
address it to EPO Patstat support at PatentData@epo.org.


The PatstatWeb Team
