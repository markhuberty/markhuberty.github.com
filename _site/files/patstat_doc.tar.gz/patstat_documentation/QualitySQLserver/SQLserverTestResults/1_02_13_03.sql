-- Check PRS instances from last 2 EP publications against espacenet legal status information -> can not be less in PATSTAT.
-- The results for the 2 releases should ofcourse be different because the latest publications can not be the same.

use patstatoct2011;
go
SELECT ('http://v3.espacenet.com/publicationDetails/biblio?CC='+[publn_auth]+'&NR='+ RTRIM(LTRIM(publn_nr))) URL_for_patstatoct2011
	  ,a.appln_auth
	  ,a.appln_nr
	  ,b.appln_id
      ,[prs_event_seq_n]
      ,[prs_gazette_date]
      ,[prs_code]
      ,[l501ep]
      ,[l504ep]
      ,[l505ep]
      ,[l506ep]
      ,[l507ep]
      ,[l510ep]
      ,[l524ep]
      FROM tls221_inpadoc_prs b join tls201_appln a on b.appln_id = a.appln_id join tls211_pat_publn d on b.appln_id = d.appln_id 
      where b.appln_id in
			  (SELECT TOP 2 c.appln_id
				FROM tls211_pat_publn c
				where c.publn_auth = 'EP' and  year(c.publn_date)< 9999
				order by c.publn_date desc)
      group by 
		publn_auth
		,publn_nr
		,a.appln_auth
		,a.appln_nr
		,b.appln_id
      ,[prs_event_seq_n]
      ,[prs_gazette_date]
      ,[prs_code]
      ,[l501ep]
      ,[l504ep]
      ,[l505ep]
      ,[l506ep]
      ,[l507ep]
      ,[l510ep]
      ,[l524ep]
     ;
go

use patstatapril2011;
go
SELECT ('http://v3.espacenet.com/publicationDetails/biblio?CC='+[publn_auth]+'&NR='+ RTRIM(LTRIM(publn_nr))) URL_for_patstatapril2011
	  ,a.appln_auth
	  ,a.appln_nr
	  ,b.appln_id
      ,[prs_event_seq_n]
      ,[prs_gazette_date]
      ,[prs_code]
      ,[l501ep]
      ,[l504ep]
      ,[l505ep]
      ,[l506ep]
      ,[l507ep]
      ,[l510ep]
      ,[l524ep]
      FROM tls221_inpadoc_prs b join tls201_appln a on b.appln_id = a.appln_id join tls211_pat_publn d on b.appln_id = d.appln_id 
      where b.appln_id in
			  (SELECT TOP 2 c.appln_id
				FROM tls211_pat_publn c
				where c.publn_auth = 'EP' and  year(c.publn_date)< 9999
				order by c.publn_date desc)
      group by 
		publn_auth
		,publn_nr
		,a.appln_auth
		,a.appln_nr
		,b.appln_id
      ,[prs_event_seq_n]
      ,[prs_gazette_date]
      ,[prs_code]
      ,[l501ep]
      ,[l504ep]
      ,[l505ep]
      ,[l506ep]
      ,[l507ep]
      ,[l510ep]
      ,[l524ep]
     ;
go

