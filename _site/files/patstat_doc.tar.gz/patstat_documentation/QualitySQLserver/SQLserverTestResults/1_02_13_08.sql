-- Check on biggest inpadoc families
-- Numbers should not go down (inpadoc_family_id is not static -> compare totals)


use patstatoct2011
go	
SELECT top 5 [inpadoc_family_id],count([appln_id]) as total	
      	
  FROM tls219_inpadoc_fam
  group by inpadoc_family_id
  order by total desc	

use patstatapril2011	
go	
SELECT top 5 [inpadoc_family_id],count([appln_id]) as total	
      	
  FROM tls219_inpadoc_fam
  group by inpadoc_family_id
  order by total desc	
