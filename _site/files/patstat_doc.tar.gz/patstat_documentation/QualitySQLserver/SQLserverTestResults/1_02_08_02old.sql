--Using the patstatproduct:
--0028-count-publications-in-PATSTAT-ECLA
--count all publications with an ECLA  symbol 
--count all publications with an ECNO (ECLA symbols allocaed by national offices not by the EPO)   symbol 
--count all publications with an ICO  symbol 
--count all publications with an IDT  symbol 

--Status in GPI on March 17th 2010 :

--41 million documents with an ECLA symbol
--250,000 docs with an ECNO symbol

--11 million docs with an ICO symbol
--9.7 million docs with a national claass symbol
--IDT is not in GPI .


use patstatoct2011
go
--count publications 
SELECT 'ECLA Publications Count:' , count(*) 
FROM tls217_APPLN_ECLA   a
    , tls211_pat_publn b
where
     a.appln_id = b.appln_id
and  epo_class_scheme = 'EC'
;
--ECLA 88,965,246......9 minutes

use patstatoct2011
go
--count applications 
SELECT 'ECLA Applications Count:' , count(*) 
FROM tls217_APPLN_ECLA   a
--    , tls211_pat_publn b
where
  --   a.appln_id = b.appln_id
  --and 
 epo_class_scheme = 'EC'
;
--ECLA 69,737,930

use patstatoct2011
go

SELECT 'ECNO Publications Count:' , count(*) 
FROM tls217_APPLN_ECLA   a
    , tls211_pat_publn b
where
     a.appln_id = b.appln_id
and  epo_class_scheme = 'ECNO'
;
-- ECNO 363.589.....3 minutes

-- count applications with ECNO
SELECT 'ECNO Applications Count:' , count(*) 
FROM tls217_APPLN_ECLA   a
--    , tls211_pat_publn b
where
 --    a.appln_id = b.appln_id
--and
  epo_class_scheme = 'ECNO'
;



use patstatapril2011
go
--count publications 
SELECT 'ECLA Publications Count:' , count(*) 
FROM tls217_APPLN_ECLA   a
    , tls211_pat_publn b
where
     a.appln_id = b.appln_id
and  epo_class_scheme = 'EC'
;
--ECLA 88,965,246......9 minutes

use patstatapril2011
go
--count applications 
SELECT 'ECLA Applications Count:' , count(*) 
FROM tls217_APPLN_ECLA   a
--    , tls211_pat_publn b
where
  --   a.appln_id = b.appln_id
  --and 
 epo_class_scheme = 'EC'
;
--ECLA 69,737,930

use patstatapril2011
go

SELECT 'ECNO Publications Count:' , count(*) 
FROM tls217_APPLN_ECLA   a
    , tls211_pat_publn b
where
     a.appln_id = b.appln_id
and  epo_class_scheme = 'ECNO'
;
-- ECNO 363.589.....3 minutes

-- count applications with ECNO
SELECT 'ECNO Applications Count:' , count(*) 
FROM tls217_APPLN_ECLA   a
--    , tls211_pat_publn b
where
 --    a.appln_id = b.appln_id
--and
  epo_class_scheme = 'ECNO'
;
--  156.527