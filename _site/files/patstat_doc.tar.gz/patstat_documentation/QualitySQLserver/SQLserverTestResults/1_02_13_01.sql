-- Check if number of PRS rows in new release has gone up.

SELECT 'tls221 Count of records patstatoct2011:' , count(*) FROM [patstatoct2011].[dbo].[tls221_inpadoc_prs];
go
SELECT 'tls221 Count of records in patstatapril2011:' , count(*) FROM [patstatapril2011].[dbo].[tls221_inpadoc_prs];
go