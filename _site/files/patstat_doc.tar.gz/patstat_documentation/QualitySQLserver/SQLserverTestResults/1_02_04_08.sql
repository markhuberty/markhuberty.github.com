       use patstatoct2011
       go
       
       SELECT
         A.APPLN_ID
       , B.PERSON_ID
       , B.DOC_STD_NAME_ID
       , C.APPLT_SEQ_NR AS APP
       , C.INVT_SEQ_NR AS INV
       , e.publn_auth as PubCC
       , e.publn_nr   as PubNR
       , e.publn_kind as PubKD
       , SUBSTRing(B.PERSON_NAME,1,25) AS PersonNAMEtruncated
       , B.PERSON_ADDRESS
       , SUBSTRing(D.DOC_STD_NAME,1,25) AS DocStandardNAME
       , B.PERSON_CTRY_CODE
              FROM [TLS201_APPLN      ] a
              ,    [TLS206_PERSON     ] b
              ,    [TLS207_PERS_APPLN ] c
              ,    [TLS208_DOC_STD_NMS ] d
              ,    [TLS211_pat_publn   ] e
       WHERE
       A.APPLN_AUTH     in ('EP','US')
       AND A.APPLN_NR   in ('       94103743'
                           ,'       85305304'
                           ,'       48851874')

    --                      '123456789012345'
       AND A.APPLN_ID  = C.APPLN_ID
       AND A.APPLN_ID  = e.APPLN_ID
       AND C.PERSON_ID = B.PERSON_ID
       AND B.DOC_STD_NAME_ID =D.DOC_STD_NAME_ID
       ORDER BY  PersonNAMEtruncated          
               , A.APPLN_ID
               , C.INVT_SEQ_NR
               , C.APPLT_SEQ_NR
               ;

 use patstatapril2011
       go
       
       SELECT
         A.APPLN_ID
       , B.PERSON_ID
       , B.DOC_STD_NAME_ID
       , C.APPLT_SEQ_NR AS APP
       , C.INVT_SEQ_NR AS INV
       , e.publn_auth as PubCC
       , e.publn_nr   as PubNR
       , e.publn_kind as PubKD
       , SUBSTRing(B.PERSON_NAME,1,25) AS PersonNAMEtruncated
       , B.PERSON_ADDRESS
       , SUBSTRing(D.DOC_STD_NAME,1,25) AS DocStandardNAME
       , B.PERSON_CTRY_CODE
              FROM [TLS201_APPLN      ] a
              ,    [TLS206_PERSON     ] b
              ,    [TLS207_PERS_APPLN ] c
              ,    [TLS208_DOC_STD_NMS ] d
              ,    [TLS211_pat_publn   ] e
       WHERE
       A.APPLN_AUTH     in ('EP','US')
       AND A.APPLN_NR   in ('       94103743'
                           ,'       85305304'
                           ,'       48851874')

    --                      '123456789012345'
       AND A.APPLN_ID  = C.APPLN_ID
       AND A.APPLN_ID  = e.APPLN_ID
       AND C.PERSON_ID = B.PERSON_ID
       AND B.DOC_STD_NAME_ID =D.DOC_STD_NAME_ID
       ORDER BY  PersonNAMEtruncated          
               , A.APPLN_ID
               , C.INVT_SEQ_NR
               , C.APPLT_SEQ_NR
               ;


   