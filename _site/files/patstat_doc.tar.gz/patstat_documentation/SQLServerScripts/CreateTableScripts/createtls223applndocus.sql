USE [patstatoct2011]
GO

/****** Object:  Table [dbo].[tls223_appln_docus]    Script Date: 08/08/2011 04:32:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tls223_appln_docus](
	[appln_id] [int] NOT NULL,
	[docus_class_symbol] [nchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[appln_id] ASC,
	[docus_class_symbol] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = ON, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[tls223_appln_docus] ADD  DEFAULT ('0') FOR [appln_id]
GO


