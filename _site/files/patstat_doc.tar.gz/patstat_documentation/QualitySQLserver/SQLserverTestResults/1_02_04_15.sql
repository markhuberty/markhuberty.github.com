-- Testing names for characters: �, �, �, �.
-- Lists between releases can have different number of row.

use patstatoct2011
go
     SELECT
       A.APPLN_ID
     , B.PERSON_ID
     , B.DOC_STD_NAME_ID
     , C.APPLT_SEQ_NR AS APP
     , C.INVT_SEQ_NR AS INV
     , e.publn_auth as PubCC
     , e.publn_nr  as PubNR
     , e.publn_kind as PubKD
     , SUBSTRING(B.PERSON_NAME,1,50) AS PersonNAMEtruncated
     , B.PERSON_ADDRESS
     , SUBSTRING(D.DOC_STD_NAME,1,35) AS DocStandardNAME
     , B.PERSON_CTRY_CODE
            FROM [tls201_APPLN ]      A
            ,    [tls206_PERSON ]     B
            ,    [tls207_PERS_APPLN ] C
            ,    [tls208_DOC_STD_NMS ] D
            ,    [tls211_pat_publn ]   E
     WHERE
	     A.APPLN_ID  = C.APPLN_ID
     AND A.APPLN_ID  = e.APPLN_ID
     AND C.PERSON_ID = B.PERSON_ID
     AND B.DOC_STD_NAME_ID =D.DOC_STD_NAME_ID
     AND
     ( (e.publn_auth ='ep' AND e.publn_nr ='        2205098')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        2126737')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        2002942')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        2210496')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        1577674')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        0500647'))
     
     ORDER BY  e.publn_nr	
             ;
             
use patstatapril2011
go
     SELECT
       A.APPLN_ID
     , B.PERSON_ID
     , B.DOC_STD_NAME_ID
     , C.APPLT_SEQ_NR AS APP
     , C.INVT_SEQ_NR AS INV
     , e.publn_auth as PubCC
     , e.publn_nr  as PubNR
     , e.publn_kind as PubKD
     , SUBSTRING(B.PERSON_NAME,1,50) AS PersonNAMEtruncated
     , B.PERSON_ADDRESS
     , SUBSTRING(D.DOC_STD_NAME,1,35) AS DocStandardNAME
     , B.PERSON_CTRY_CODE
            FROM [tls201_APPLN ]      A
            ,    [tls206_PERSON ]     B
            ,    [tls207_PERS_APPLN ] C
            ,    [tls208_DOC_STD_NMS ] D
            ,    [tls211_pat_publn ]   E
     WHERE
	     A.APPLN_ID  = C.APPLN_ID
     AND A.APPLN_ID  = e.APPLN_ID
     AND C.PERSON_ID = B.PERSON_ID
     AND B.DOC_STD_NAME_ID =D.DOC_STD_NAME_ID
     AND
     ( (e.publn_auth ='ep' AND e.publn_nr ='        2205098')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        2126737')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        2002942')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        2210496')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        1577674')
     or  (e.publn_auth ='ep' AND e.publn_nr ='        0500647'))
     
     ORDER BY  e.publn_nr;
     