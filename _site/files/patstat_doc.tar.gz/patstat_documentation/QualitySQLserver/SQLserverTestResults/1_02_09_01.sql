-- DOCDB test

-- When comparing results with the Esp@cenet simple family:
-- Remember that: DE-D documents are not given in espacenet (they are not in EPODOC), so you will not find it there
-- Only one publication step is indicated, except for the one document you are looking at-> JP4070462B2 is not visible in espacenet.
-- PATSTAT als includes the queried document itself in the list, espacenet will show extra publication instances for EP1592083



use patstatoct2011
go
select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind, e.publn_date
from 
  [tls201_appln] d
, [tls211_pat_publn] e
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls218_docdb_fam] b
, [tls218_docdb_fam] c
where
   a.publn_auth = 'EP'
--and a.publn_nr = '        1000000'
and a.publn_nr = '        1592083' -- jouve had this as a pct not a div
--and a.publn_kind = 'A1'
and b.docdb_family_id = c.docdb_family_id 
and    b.appln_id = a.appln_id
   )

order by e.publn_date
;
use patstatapril2011 
go
select d.appln_id , d.appln_auth, d.appln_nr, d.appln_kind  
, e.publn_auth, e.publn_nr, e.publn_kind, e.publn_date
from 
  [tls201_appln] d
, [tls211_pat_publn] e
where d.appln_id = e.appln_id
and d.appln_id in (
select c.appln_id   from

  [tls211_pat_publn] a
, [tls218_docdb_fam] b
, [tls218_docdb_fam] c
where
   a.publn_auth = 'EP'
--and a.publn_nr = '        1000000'
and a.publn_nr = '        1592083' -- jouve had this as a pct not a div
--and a.publn_kind = 'A1'
and b.docdb_family_id = c.docdb_family_id 
and    b.appln_id = a.appln_id
   )

order by e.publn_date
;