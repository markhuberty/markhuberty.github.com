## Mark Huberty
## 6 June 2010
## Code to test the new GenMatch function
#setwd("~/Documents/gpuGenMatch/gpuGenMatch/testing/")
setwd("~/Documents/Technology/gpuGenMatch/GenMatch/testing/")
#setwd("~/devel/gpuGenMatch/testing")
                                        #setwd("/Users/markhuberty/")
#setwd("~/package/testing")

library(Matching,
        lib.loc="./library",
        verbose=TRUE
        )

## Bring in the data
data(lalonde)

rowcount <-  dim(lalonde)[1]

## make the test data set very small; data frame is sorted with Tr
## first

## Note that somewhere between 300-350 total sample size, the GPU
## stops reproducing the CPU results. Not sure why. Times are
## comparable at the moment in any case;

n <- 100;
lalonde = lalonde[c(1:n, (rowcount - n):rowcount),]

#lalonde = rbind(lalonde, lalonde)

#lalonde3 <- rbind(lalonde, lalonde, lalonde)

#lalonde <- lalonde[1:100,]
#attach(lalonde3)
attach(lalonde)

#The covariates we want to match on
X = cbind(age, educ, black, hisp, married, nodegr, u74, u75, re75, re74);
seed <- 38212
pl <- 1


## 1461
set.seed(2316)
## genout.old <- GenMatch(Tr=treat,
##                       X=X,
##                       gpu=FALSE,
##                       ties=TRUE,
##                       unif.seed=seed,
##                       print.level=pl
##                       )
## 
## Test for FasterMatch
##
## ## set.seed(2316)
genout.gpu <- GenMatch(Tr=treat,
                       X=X,
                       #BalanceMatrix=X[,1],
                       #ks=FALSE,
                       #nboots=0,
                       gpu=TRUE,
                       ties=TRUE,
                       unif.seed=seed,
                       print.level=pl,
                       distance.tolerance=0.0001
		       )  


## genout.new <- GenMatch(Tr=treat,
##                        X=X,
##                        BalanceMatrix=X[,1],
##                        gpu=FALSE,
##                        ties=TRUE,
##                        ks=FALSE,
##                        nboots=0,
##                        unif.seed=seed,
##                        print.level=pl,
##                        distance.tolerance=0.0001
## 		       )    



detach(lalonde)

#detach(lalonde3)

#attach(lalonde2)

#X = cbind(age, educ, black, hisp, married, nodegr, u74, u75, re75, re74);

#genout.old.2 <- GenMatch(Tr=treat,
#                       X=X,
#                       beta=FALSE,
#                       ties=TRUE,
#                       unif.seed=seed,
#                       print.level=pl                       
#                       )



#genout.new.2 <- GenMatch(Tr=treat,
#                       X=X,
#                       beta=TRUE,
#                       ties=TRUE,
#                       unif.seed=seed,
#                       print.level=pl                       
#                       )
#detach(lalonde2)


## ## Benchmarking
## N <- 5
## seed <- 2842
## genout.old.timing <- sapply(1:N, function(x){
##     set.seed(seed)
##     system.time(GenMatch(Tr=treat,
##                          X=X,
##                          beta=FALSE,
##                          ties=TRUE
##                          )
##                 )
    
## }
##                             )

## genout.new.timing <- sapply(1:N, function(x){
##     set.seed(seed)
##     system.time(GenMatch(Tr=treat,
##                          X=X,
##                          beta=TRUE,
##                          ties=TRUE
##                          )
##                 )
    
## }
##                             )

