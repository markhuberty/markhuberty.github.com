use patstatoct2011
go
  SELECT
      person_name
     ,person_address
     ,person_ctry_code         as PersCC
     ,publn_auth               as PubCC
     ,publn_nr                 as PNR
     ,publn_kind               as PKD
     ,publn_date               as Published
     ,doc_std_name             as DocStdName
     ,applt_seq_nr             as AppSeq
     ,invt_seq_nr              as InvSeq
   FROM
   [TLS206_person   ] c
  ,[TLS207_pers_appln ] d
  ,[TLS208_doc_std_nms ] e
  ,[TLS211_pat_publn ] b
  where
      d.appln_id = b.appln_id
  and d.person_id = c.person_id
  and c.doc_std_name_id = e.doc_std_name_id
  and b.publn_auth = 'EP'
  and b.publn_nr   = '        0086411'
  order by invt_seq_nr, person_name
  ;
        
        
  use patstatapril2011
go
  SELECT
      person_name
     ,person_address
     ,person_ctry_code         as PersCC
     ,publn_auth               as PubCC
     ,publn_nr                 as PNR
     ,publn_kind               as PKD
     ,publn_date               as Published
     ,doc_std_name             as DocStdName
     ,applt_seq_nr             as AppSeq
     ,invt_seq_nr              as InvSeq
   FROM
   [TLS206_person   ] c
  ,[TLS207_pers_appln ] d
  ,[TLS208_doc_std_nms ] e
  ,[TLS211_pat_publn ] b
  where
      d.appln_id = b.appln_id
  and d.person_id = c.person_id
  and c.doc_std_name_id = e.doc_std_name_id
  and b.publn_auth = 'EP'
  and b.publn_nr   = '        0086411'
  order by invt_seq_nr, person_name
  ;
        
        
  