 -- According to the data catalog (6.6.3) artificial entires for citations should have application and publication date set to 9999.
 -- This is not the case for the publication dates for the last 2 releases.  (application date is set to 9999, but not publication date)
 -- The result of this test should be 0.
 
 
 use patstatoct2011
 go
 
 SELECT  a.publn_Auth, YEAR(publn_date), COUNT(a.pat_publn_id)
   FROM [TLS211_PAT_PUBLN  ] a
      , [TLS201_APPLN  ] b
   WHERE A.APPLN_ID = B.APPLN_ID
        AND B.APPLN_KIND = 'D2'
        and publn_date <>  '9999-12-31'
 group by a.publn_Auth, YEAR(publn_date)
 order by publn_auth desc, YEAR(publn_date) desc
   ;
   
   use patstatapril2011
 go
 
 SELECT  a.publn_Auth, YEAR(publn_date), COUNT(a.pat_publn_id)
   FROM [TLS211_PAT_PUBLN  ] a
      , [TLS201_APPLN  ] b
   WHERE A.APPLN_ID = B.APPLN_ID
        AND B.APPLN_KIND = 'D2'
        and publn_date <>  '9999-12-31'
 group by a.publn_Auth, YEAR(publn_date)
 order by publn_auth desc, YEAR(publn_date) desc
   ;