-- abstract table query
-- the number of abstracts for the 2 queries should in principle not go down in a new release.
-- april 2011: 854
-- october 2011: 1761
-- april 2012: xxx
-- october 2012: xxx

use patstatoct2011
go
  SELECT a.appln_id, b.appln_abstract, a.publn_auth, a.publn_nr, a.publn_kind, a.publn_date
   FROM
   TLS203_APPLN_abstr  b,
   TLS211_PAT_PUBLN  a
     where a.appln_id = b.appln_id
     and a.publn_date = '2010-01-15'
     --and appln_abstract like 'nano%'
     order by appln_id asc
          
     ;
   
use patstatapril2011
go
  SELECT a.appln_id, b.appln_abstract, a.publn_auth, a.publn_nr, a.publn_kind, a.publn_date
   FROM
   TLS203_APPLN_abstr  b,
   TLS211_PAT_PUBLN  a
     where a.appln_id = b.appln_id
     and a.publn_date = '2010-01-15'
     --and appln_abstract like 'nano%'
     order by appln_id asc
          
     ;
   