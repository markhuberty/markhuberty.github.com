-- This runs a set of scripts to load a database table
--
--
-- Version March2008    Created by Tony Teculescu    on 04/03/2008    
--

alter table TLS208_DOC_STD_NMS disable keys;
load data local infile '<enter path of unzipped files here>\\tls208_part01.txt' into table TLS208_DOC_STD_NMS fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
alter table TLS208_DOC_STD_NMS enable keys;