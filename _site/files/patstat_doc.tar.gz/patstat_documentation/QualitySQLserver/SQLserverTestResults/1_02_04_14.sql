use patstatoct2011
go

SELECT
      publn_auth
     ,publn_nr
     ,publn_kind
     ,person_name
     ,d.appln_id
     ,b.person_id
     ,c.invt_seq_nr
     ,c.applt_seq_nr
   FROM
   --[TLS201_APPLN ]  a
  [TLS206_PERSON ]  b
  ,[TLS207_PERS_APPLN ]  c
  ,tls211_pat_publn  d
  where  publn_auth = 'US'
  and d.publn_nr = '        4000000'
  and d.appln_id = c.appln_id
  and b.person_id = c.person_id
--  and   invt_seq_nr > 0
   order by publn_nr, person_name
  ;
  
  use patstatapril2011
go

SELECT
      publn_auth
     ,publn_nr
     ,publn_kind
     ,person_name
     ,d.appln_id
     ,b.person_id
     ,c.invt_seq_nr
     ,c.applt_seq_nr
   FROM
  [TLS206_PERSON ]  b
  ,[TLS207_PERS_APPLN ]  c
  ,tls211_pat_publn  d
  where  publn_auth = 'US'
  and d.publn_nr = '        4000000'
  and d.appln_id = c.appln_id
  and b.person_id = c.person_id
   order by publn_nr, person_name
  ;