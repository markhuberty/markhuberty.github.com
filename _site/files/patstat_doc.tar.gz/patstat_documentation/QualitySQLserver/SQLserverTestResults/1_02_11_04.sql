-- Creates a list of all applications that appeared in the previous release but not in the latest one.
-- This should normally not happen with applications that are not replenished but it 
-- is possible because of corrections of for example kind-codes or any other major re.keying of data.
-- The boundry of dummy applications might need to be changed.

-- October2011 26665 row(s) affected)



use patstatapril2011
go
SELECT a.appln_id,a.appln_auth+a.appln_nr+a.appln_kind
FROM [tls201_appln] a
WHERE ((a.appln_auth+a.appln_nr+a.appln_kind) not in (select (c.appln_auth+c.appln_nr+c.appln_kind) from [patstatoct2011].[dbo].[tls201_appln]c ))
		and a.appln_id < 900000000
order by a.appln_auth+a.appln_nr+a.appln_kind;