-- Check PRS instances from EP1000000 (fixed appln_id = 17397285) against espacenet legal status information.
-- http://worldwide.espacenet.com/publicationDetails/inpadoc?CC=EP&NR=1000000A1&KC=A1&FT=D&date=20000517&DB=EPODOC&locale=en_T1
-- Additional instances can have occured, check if tags and content between 2 releases are the same for the old instances.
-- There can not be more events then what is available via espacenet.

use patstatoct2011;
go
SELECT [appln_id]
      ,[prs_event_seq_n]
      ,[prs_gazette_date]
      ,[prs_code]
      ,[l501ep]
      ,[l504ep]
      ,[l505ep]
      ,[l506ep]
      ,[l507ep]
      ,[l510ep]
      ,[l524ep]
      FROM tls221_inpadoc_prs
      where appln_id = 17397285
      group by [appln_id]
      ,[prs_event_seq_n]
      ,[prs_gazette_date]
      ,[prs_code]
      ,[l501ep]
      ,[l504ep]
      ,[l505ep]
      ,[l506ep]
      ,[l507ep]
      ,[l510ep]
      ,[l524ep]
     ;
go

use patstatapril2011;
go
SELECT [appln_id]
      ,[prs_event_seq_n]
      ,[prs_gazette_date]
      ,[prs_code]
      ,[l501ep]
      ,[l504ep]
      ,[l505ep]
      ,[l506ep]
      ,[l507ep]
      ,[l510ep]
      ,[l524ep]
      FROM tls221_inpadoc_prs
      where appln_id = 17397285
      group by [appln_id]
      ,[prs_event_seq_n]
      ,[prs_gazette_date]
      ,[prs_code]
      ,[l501ep]
      ,[l504ep]
      ,[l505ep]
      ,[l506ep]
      ,[l507ep]
      ,[l510ep]
      ,[l524ep]
     ;
go




