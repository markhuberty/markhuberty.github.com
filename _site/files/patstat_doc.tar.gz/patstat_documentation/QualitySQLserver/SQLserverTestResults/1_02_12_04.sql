--extension on test 1_02_12_01, where we now check the last 3 EP publications for the releases.
--change dummy application boundery if needed.
--results should be different with previous release.
--check that title an abstract information is (most probably) available.


use patstatoct2011
go
  SELECT
      appln_auth               as CC
     ,appln_nr                 as NR
     ,appln_kind               as KD
     ,appln_filing_Date        as Filed
     ,ipr_type                 as IPR
     ,appln_title_lg           as titlg
     ,appln_abstract_lg        as abslg
     ,a.appln_id               as appln_id
     ,a.internat_appln_id      as PCTappln
     ,b.publn_auth
     ,b.publn_nr		  
     ,b.publn_date				
   FROM
   [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where
      a.appln_id = b.appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   in (
  SELECT TOP 3 [publn_nr]
  FROM tls211_pat_publn join tls201_appln on tls201_appln.appln_id = tls211_pat_publn.appln_id
  where publn_auth = 'EP' and tls201_appln.appln_id < 900000000 
  order by publn_date desc);
                    
                    
  SELECT
      appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,publn_auth               as PubCC
     ,publn_nr                 as PubNR
     ,publn_kind               as PubKD
     ,appln_title              as title
     ,appln_abstract           as abstract
     ,appln_title_lg           as titlg
     ,appln_abstract_lg        as abslg
   FROM
   [TLS201_APPLN ] a
  ,[TLS202_appln_title ] c
  ,[TLS203_appln_abstr ] d
  ,[TLS211_pat_publn ] b
  where
      a.appln_id = b.appln_id
  and a.appln_id = c.appln_id
  and a.appln_id = d.appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   in (
		  SELECT TOP 3 [publn_nr]
		  FROM tls211_pat_publn join tls201_appln on tls201_appln.appln_id = tls211_pat_publn.appln_id
		  where publn_auth = 'EP' and tls201_appln.appln_id < 900000000 
		  order by publn_date desc)
  ;
 
 
  SELECT
      a.appln_auth               as AppCC
     ,a.appln_nr                 as AppNR
     ,a.appln_kind               as AppKD
     ,a.appln_filing_date        as AppFiling
     ,c.prior_appln_seq_nr       as PrioSeq
     ,publn_auth               as PCC
     ,publn_nr                 as PNR
     ,publn_kind               as PKD
   FROM
   [TLS201_APPLN ] a
  ,[TLS204_appln_prior ] c
  ,[TLS211_pat_publn  ] b
  where
      c.appln_id = b.appln_id
  and a.appln_id = c.prior_appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   in (
				  SELECT TOP 3 [publn_nr]
				  FROM tls211_pat_publn join tls201_appln on tls201_appln.appln_id = tls211_pat_publn.appln_id
				  where publn_auth = 'EP' and tls201_appln.appln_id < 900000000 
				  order by publn_date desc)
  ;
            
use patstatapril2011
go
  SELECT
      appln_auth               as CC
     ,appln_nr                 as NR_PASTSTATSEPT2010
     ,appln_kind               as KD
     ,appln_filing_Date        as Filed
     ,ipr_type                 as IPR
     ,appln_title_lg           as titlg
     ,appln_abstract_lg        as abslg
     ,a.appln_id               as appln_id
     ,a.internat_appln_id      as PCTappln
     ,b.publn_auth
     ,b.publn_nr		  
     ,b.publn_date	
   FROM
   [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where
      a.appln_id = b.appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   in (
				  SELECT TOP 3 [publn_nr]
				  FROM tls211_pat_publn join tls201_appln on tls201_appln.appln_id = tls211_pat_publn.appln_id
				  where publn_auth = 'EP' and tls201_appln.appln_id < 900000000 
				  order by publn_date desc)
  ;
                    
                    
  SELECT
      appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,publn_auth               as PubCC
     ,publn_nr                 as PubNR
     ,publn_kind               as PubKD
     ,appln_title              as title
     ,appln_abstract           as abstract
     ,appln_title_lg           as titlg
     ,appln_abstract_lg        as abslg
   FROM
   [TLS201_APPLN ] a
  ,[TLS202_appln_title ] c
  ,[TLS203_appln_abstr ] d
  ,[TLS211_pat_publn ] b
  where
      a.appln_id = b.appln_id
  and a.appln_id = c.appln_id
  and a.appln_id = d.appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   in (
					  SELECT TOP 3 [publn_nr]
					  FROM tls211_pat_publn join tls201_appln on tls201_appln.appln_id = tls211_pat_publn.appln_id
					  where publn_auth = 'EP' and tls201_appln.appln_id < 900000000 
					  order by publn_date desc)
  ;
 
 
  SELECT
      a.appln_auth               as AppCC
     ,a.appln_nr                 as AppNR
     ,a.appln_kind               as AppKD
     ,a.appln_filing_date        as AppFiling
     ,c.prior_appln_seq_nr       as PrioSeq
     ,publn_auth               as PCC
     ,publn_nr                 as PNR
     ,publn_kind               as PKD
   FROM
   [TLS201_APPLN ] a
  ,[TLS204_appln_prior ] c
  ,[TLS211_pat_publn  ] b
  where
      c.appln_id = b.appln_id
  and a.appln_id = c.prior_appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   in (
				  SELECT TOP 3 [publn_nr]
				  FROM tls211_pat_publn join tls201_appln on tls201_appln.appln_id = tls211_pat_publn.appln_id
				  where publn_auth = 'EP' and tls201_appln.appln_id < 900000000 
				  order by publn_date desc)
  ;