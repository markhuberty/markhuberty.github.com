--0055-compare-symbols-with-espacenet

-- for EP 1000001  and US 4000000

use patstatoct2011
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'EP'
  and publn_nr = '        1000001' )
  or 
   (publn_auth = 'US'
  and publn_nr = '        4000000' )
  )
  and  a.appln_id = b.appln_id
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
GO



;

use patstatapril2011
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'EP'
  and publn_nr = '        1000001' )
  or 
   (publn_auth = 'US'
  and publn_nr = '        4000000' )
  )
  and  a.appln_id = b.appln_id
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
GO
;

