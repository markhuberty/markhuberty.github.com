-- Check if JP abstracts are available for publication dates in specified range.)
-- Number of abstracts can not go down in a new version.

use patstatoct2011
go
  SELECT a.appln_id, b.appln_abstract, a.publn_auth, a.publn_nr, a.publn_kind, a.publn_date
   FROM
   TLS203_APPLN_abstr  b,
   TLS211_PAT_PUBLN  a
     where a.appln_id = b.appln_id
     and (a.publn_date in('2002-07-24', '2011-03-24'))
     --and appln_abstract like 'nano%'
     and publn_auth =  'jp'
     order by appln_id asc;
     
     
use patstatapril2011
go
  SELECT a.appln_id, b.appln_abstract, a.publn_auth, a.publn_nr, a.publn_kind, a.publn_date
   FROM
   TLS203_APPLN_abstr  b,
   TLS211_PAT_PUBLN  a
     where a.appln_id = b.appln_id
     and (a.publn_date in('2002-07-24', '2011-03-24'))
     --and appln_abstract like 'nano%'
     and publn_auth =  'jp'
     order by appln_id asc;
   

   