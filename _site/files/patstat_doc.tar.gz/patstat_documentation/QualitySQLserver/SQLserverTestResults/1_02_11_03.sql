-- Test to look for D2 applications that do NOT have 9999-12-31 date.
-- According to businnes model this should not occur.


Use patstatoct2011
go
SELECT Year([appln_filing_date]),tls201_appln.appln_auth, tls201_appln.appln_kind, Count(tls201_appln.appln_id) AS numberD2no9999
FROM tls201_appln
GROUP BY Year([appln_filing_date]), tls201_appln.appln_auth, tls201_appln.appln_kind
HAVING (((Year([appln_filing_date]))<>9999) AND ((tls201_appln.appln_kind)='D2'))
ORDER BY tls201_appln.appln_auth, Year([appln_filing_date]);

use patstatapril2011
go
SELECT Year([appln_filing_date]),tls201_appln.appln_auth, tls201_appln.appln_kind, Count(tls201_appln.appln_id) AS numberD2no9999
FROM tls201_appln
GROUP BY Year([appln_filing_date]), tls201_appln.appln_auth, tls201_appln.appln_kind
HAVING (((Year([appln_filing_date]))<>9999) AND ((tls201_appln.appln_kind)='D2'))
ORDER BY tls201_appln.appln_auth, Year([appln_filing_date]);