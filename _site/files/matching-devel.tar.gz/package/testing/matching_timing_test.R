## Mark Huberty
## 6 June 2010
## Code to test the new GenMatch function
#setwd("~/Documents/gpuGenMatch/gpuGenMatch/testing/")
#setwd("~/Documents/Technology/gpuGenMatch/GenMatch/testing/")
#setwd("~/devel/gpuGenMatch/testing")
                                        #setwd("/Users/markhuberty/")
setwd("~/package/testing")

library(Matching,
        lib.loc="./library",
        verbose=TRUE
        )

## Bring in the data
data(lalonde)

data.tr <- lalonde[lalonde$treat==1,]
data.ctl <- lalonde[lalonde$treat==0,]

rows.tr <- dim(data.tr)[1]
rows.ctl <- dim(data.ctl)[1]


## make the test data set very small; data frame is sorted with Tr
## first

## Note that somewhere between 300-350 total sample size, the GPU
## stops reproducing the CPU results. Not sure why. Times are
## comparable at the moment in any case;

n.tr <- 50
n.ctl <- 54
frac.tr <- n.tr/sum(c(n.tr, n.ctl))
frac.ctl <- n.ctl/sum(c(n.tr, n.ctl))

data.tr.start <- data.tr[sample(1:rows.tr, n.tr, replace=FALSE),]
data.ctl.start <- data.ctl[sample(1:rows.ctl, n.ctl, replace=FALSE),]

data <- rbind(data.tr.start, data.ctl.start)


timings <- list()



#The covariates we want to match on
seed <- 38212
pl <- 1


## 1461
set.seed(2316)
## genout.old <- GenMatch(Tr=treat,
##                       X=X,
##                       gpu=FALSE,
##                       ties=TRUE,
##                       unif.seed=seed,
##                       print.level=pl
##                       )

## Test for FasterMatch
##
set.seed(2316)

N <- 2000
by.n <- 25
sizes <- seq(from=(n.tr + n.ctl), to=N, by=by.n)
sapply(1:length(sizes), function(x){

  if(x==1)
    {
      attach(data)
    }
  else
    {
      n.tr <- ceiling(frac.tr*sizes[x])
      n.ctl <- ceiling(frac.ctl*sizes[x])

      data.tr.n <- data.tr[sample(1:rows.tr, n.tr, replace=TRUE),]
      data.ctl.n <- data.ctl[sample(1:rows.tr, n.tr, replace=TRUE),]
      data <- rbind(data.tr.n, data.ctl.n)
      attach(data)
    }

  
  X = cbind(age, educ, black, hisp, married, nodegr, u74, u75, re75, re74);

  time.gpu <- system.time(
                          genout.gpu <- GenMatch(Tr=treat,
                                                 X=X,
                                                 gpu=TRUE,
                                                 ties=TRUE,
                                                 unif.seed=seed,
                                                 print.level=pl,
                                                 distance.tolerance=0.0001
                                                 )  
                          )

  time.cpu <- system.time(
                          genout.new <- GenMatch(Tr=treat,
                                                 X=X,
                                                 gpu=FALSE,
                                                 ties=TRUE,
                                                 unif.seed=seed,
                                                 print.level=pl,
                                                 distance.tolerance=0.0001
                                                 )    
                          )

  dim.data <- dim(data)[1]
  detach(data)
  time.out <- c(dim.data,time.gpu[3], time.cpu[3])
  timings[[x]] <- time.out
  ##return(time.out)

  
}
       )
#detach(lalonde3)

#attach(lalonde2)

#X = cbind(age, educ, black, hisp, married, nodegr, u74, u75, re75, re74);

#genout.old.2 <- GenMatch(Tr=treat,
#                       X=X,
#                       beta=FALSE,
#                       ties=TRUE,
#                       unif.seed=seed,
#                       print.level=pl                       
#                       )



#genout.new.2 <- GenMatch(Tr=treat,
#                       X=X,
#                       beta=TRUE,
#                       ties=TRUE,
#                       unif.seed=seed,
#                       print.level=pl                       
#                       )
#detach(lalonde2)


## ## Benchmarking
## N <- 5
## seed <- 2842
## genout.old.timing <- sapply(1:N, function(x){
##     set.seed(seed)
##     system.time(GenMatch(Tr=treat,
##                          X=X,
##                          beta=FALSE,
##                          ties=TRUE
##                          )
##                 )
    
## }
##                             )

## genout.new.timing <- sapply(1:N, function(x){
##     set.seed(seed)
##     system.time(GenMatch(Tr=treat,
##                          X=X,
##                          beta=TRUE,
##                          ties=TRUE
##                          )
##                 )
    
## }
##                             )

