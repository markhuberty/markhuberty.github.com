-- This runs a set of scripts to load a database table
--
--
-- Version March2008    Created by Tony Teculescu    on 04/03/2008    
--


load data local infile '<enter path of unzipped files here>\\tls203_part01.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part02.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part03.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part04.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part05.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part06.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part07.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part08.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part09.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part10.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part11.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part12.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part13.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls203_part14.txt' into table TLS203_APPLN_ABSTR fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
