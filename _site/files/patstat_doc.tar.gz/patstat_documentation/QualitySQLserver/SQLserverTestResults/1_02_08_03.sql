--0052-count-documents-with-at-least-1-ECLA
--Compare against GPI result

use patstatoct2011
go
--count(distinct (pat_publn_id)) 
--count publications 
SELECT 'ECLA Publications Count:' , count(*)

from    tls211_pat_publn b
where
 --    a.appln_id = b.appln_id
      b.appln_id  in (
select distinct a.appln_id 
FROM tls217_APPLN_ECLA   a 
where  epo_class_scheme = 'EC'
)
;


use patstatapril2011
go
--count(distinct (pat_publn_id)) 
--count publications 
SELECT 'ECLA Publications Count:' , count(*)

from    tls211_pat_publn b
where
 --    a.appln_id = b.appln_id
      b.appln_id  in (
select distinct a.appln_id 
FROM tls217_APPLN_ECLA   a 
where  epo_class_scheme = 'EC'
)
;
