use patstatoct2011
go
  SELECT
      appln_auth               as CC
     ,appln_nr                 as NR
     ,appln_kind               as KD
     ,appln_filing_Date        as Filed
     ,ipr_type                 as IPR
     ,appln_title_lg           as titlg
     ,appln_abstract_lg        as abslg
     ,a.appln_id               as appln_id
     ,a.internat_appln_id      as PCTappln
   FROM
   [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where
      a.appln_id = b.appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   = '        1000000'
  ;
                    
                    
  SELECT
      appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,publn_auth               as PubCC
     ,publn_nr                 as PubNR
     ,publn_kind               as PubKD
     ,appln_title              as title
     ,appln_abstract           as abstract
     ,appln_title_lg           as titlg
     ,appln_abstract_lg        as abslg
   FROM
   [TLS201_APPLN ] a
  ,[TLS202_appln_title ] c
  ,[TLS203_appln_abstr ] d
  ,[TLS211_pat_publn ] b
  where
      a.appln_id = b.appln_id
  and a.appln_id = c.appln_id
  and a.appln_id = d.appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   = '        1000000'
  ;
 
 
  SELECT
      a.appln_auth               as AppCC
     ,a.appln_nr                 as AppNR
     ,a.appln_kind               as AppKD
     ,a.appln_filing_date        as AppFiling
     ,c.prior_appln_seq_nr       as PrioSeq
     ,publn_auth               as PCC
     ,publn_nr                 as PNR
     ,publn_kind               as PKD
   FROM
   [TLS201_APPLN ] a
  ,[TLS204_appln_prior ] c
  ,[TLS211_pat_publn  ] b
  where
      c.appln_id = b.appln_id
  and a.appln_id = c.prior_appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   = '        1000000'
  ;
            
use patstatapril2011
go
  SELECT
      appln_auth               as CC
     ,appln_nr                 as NR
     ,appln_kind               as KD
     ,appln_filing_Date        as Filed
     ,ipr_type                 as IPR
     ,appln_title_lg           as titlg
     ,appln_abstract_lg        as abslg
     ,a.appln_id               as appln_id
     ,a.internat_appln_id      as PCTappln
   FROM
   [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where
      a.appln_id = b.appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   = '        1000000'
  ;
                    
                    
  SELECT
      appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,publn_auth               as PubCC
     ,publn_nr                 as PubNR
     ,publn_kind               as PubKD
     ,appln_title              as title
     ,appln_abstract           as abstract
     ,appln_title_lg           as titlg
     ,appln_abstract_lg        as abslg
   FROM
   [TLS201_APPLN ] a
  ,[TLS202_appln_title ] c
  ,[TLS203_appln_abstr ] d
  ,[TLS211_pat_publn ] b
  where
      a.appln_id = b.appln_id
  and a.appln_id = c.appln_id
  and a.appln_id = d.appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   = '        1000000'
  ;
 
 
  SELECT
      a.appln_auth               as AppCC
     ,a.appln_nr                 as AppNR
     ,a.appln_kind               as AppKD
     ,a.appln_filing_date        as AppFiling
     ,c.prior_appln_seq_nr       as PrioSeq
     ,publn_auth               as PCC
     ,publn_nr                 as PNR
     ,publn_kind               as PKD
   FROM
   [TLS201_APPLN ] a
  ,[TLS204_appln_prior ] c
  ,[TLS211_pat_publn  ] b
  where
      c.appln_id = b.appln_id
  and a.appln_id = c.prior_appln_id
  and b.publn_auth = 'EP'
  and b.publn_nr   = '        1000000'
  ;
            
             