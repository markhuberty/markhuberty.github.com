#!/bin/bash

rm -r ./Matching
rm -r ./library/Matching
cp -r ../Matching ./

# Get the OS
UNAME=`uname -a`

echo $UNAME | grep -i Darwin > /dev/null 2>&1
if test "$?" = 0 ; then
    cp ./Matching/inst/extras/Makevars.osx ./Matching/src/Makevars.in
    #dest_lib = i386
else
    cp ./Matching/inst/extras/Makevars.lin ./Matching/src/Makevars.in
    #dest_lib = x86_64
fi

cd ./Matching
./configure

cd ./src/cuda
echo $UNAME | grep -i Darwin > /dev/null 2>&1
if test "$?" = 0 ; then
    nvcc -c --ptxas-options=-v gpuFasterMatchC.cu -I/Developer/GPU\ Computing/C/common/inc -I$CUDA_HOME/include -L$CUDA_HOME/lib  -L/Developer/GPU\ Computing/C/common/lib -L/Developer/GPU\ Computing/C/lib  -lcuda -lcudart -lcutil_i386
else #on linux, assume 64-bit
    nvcc -c gpuFasterMatchC.cu -I$HOME/NVIDIA_GPU_Computing_SDK/C/common/inc -I$CUDA_HOME/include -L$CUDA_HOME/lib64  -L$HOME/NVIDIA_GPU_Computing_SDK/C/common/lib  -L$HOME/NVIDIA_GPU_Computing_SDK/C/common/lib/linux -lcuda -lcudart -lcutil_x86_64 -Xcompiler -fpic
fi

cd ..
cp ./cuda/gpuFasterMatchC.o ./
cp ./cuda/host_gpuFasterMatchC.h ./
R CMD SHLIB *.c* gpuFasterMatchC.o -o Matching.so

cd ../../
## Note the --no-test-load is necessary on R 2.11+; don't know why this fails, does 
## not affect the package
R CMD INSTALL --no-test-load --no-libs ./Matching -l ./library
mkdir ./library/Matching/libs
#mkdir ./library/Matching/libs/
cp ./Matching/src/Matching.so ./library/Matching/libs/
#R CMD SHLIB matching.cc malloc.c scythematrix.cc gpuRadixSort.cc 
#rm matching.so
#R CMD SHLIB *.o ./cuda/radixsort.o -o Matching.so

#cd ../../
#R CMD INSTALL ./Matching -l ./library
