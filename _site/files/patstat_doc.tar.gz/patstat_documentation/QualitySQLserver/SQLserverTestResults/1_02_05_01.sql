use patstatoct2011
go
 select a.appln_id   
, a.publn_auth, a.publn_nr, a.publn_kind 
      ,[ipc_class_symbol]
      ,[ipc_class_level]
      ,[ipc_version]
      ,[ipc_value]
      ,[ipc_position]
      ,[ipc_gener_auth]
from 
  [tls211_pat_publn] a
, [tls209_appln_ipc] f
where a.appln_id in (
select d.appln_id 
from 
  [tls211_pat_publn] a
, [tls218_docdb_fam] b
, [tls218_docdb_fam] c
, [tls201_appln] d

where b.appln_id = a.appln_id
and a.publn_auth = 'EP'
and a.publn_nr = '        1654607'
and a.publn_kind = 'A1'
and b.docdb_family_id = c.docdb_family_id 
and d.appln_id = c.appln_id
)
and a.appln_id = f.appln_id
order by a.publn_auth, a.publn_nr, a.publn_kind , ipc_class_level, ipc_class_symbol
;

--IPC symbols for a DocDB simple family, starting with a publication in the family:
--runs in 2 seconds:
use patstatapril2011
go
 select a.appln_id   
, a.publn_auth, a.publn_nr, a.publn_kind 
      ,[ipc_class_symbol]
      ,[ipc_class_level]
      ,[ipc_version]
      ,[ipc_value]
      ,[ipc_position]
      ,[ipc_gener_auth]
from 
  [tls211_pat_publn] a
, [tls209_appln_ipc] f
where a.appln_id in (
select d.appln_id 
from 
  [tls211_pat_publn] a
, [tls218_docdb_fam] b
, [tls218_docdb_fam] c
, [tls201_appln] d

where b.appln_id = a.appln_id
and a.publn_auth = 'EP'
and a.publn_nr = '        1654607'
and a.publn_kind = 'A1'
and b.docdb_family_id = c.docdb_family_id 
and d.appln_id = c.appln_id
)
and a.appln_id = f.appln_id
order by a.publn_auth, a.publn_nr, a.publn_kind , ipc_class_level, ipc_class_symbol
;

--IPC symbols for a DocDB simple family, starting with a publication in the family:
--runs in 2 seconds:
