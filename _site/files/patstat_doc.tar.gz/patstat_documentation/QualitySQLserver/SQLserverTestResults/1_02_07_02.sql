use patstatoct2011;
go
  SELECT 'count D2 application' , COUNT(*) FROM
  [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where a.appln_kind = 'D2'
  and a.appln_id = b.appln_id
   ;
   
   SELECT 'count D2 application' , COUNT(*) FROM
   [TLS201_APPLN ] a
  where a.appln_kind = 'D2'
   ;
   
                                               
  SELECT  'minimum D2 publication id' , MIN(pat_publn_id) from
   [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where a.appln_kind = 'D2'
  and a.appln_id = b.appln_id
   ;
   
                                               
  SELECT  'maximum D2 publication id' , Max(pat_publn_id) from
   [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where a.appln_kind = 'D2'
  and a.appln_id = b.appln_id
   ;
   
                                             
   use patstatapril2011
go
  SELECT 'count D2 application' , COUNT(*) FROM
  [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where a.appln_kind = 'D2'
  and a.appln_id = b.appln_id
   ;
   
   SELECT 'count D2 application' , COUNT(*) FROM
   [TLS201_APPLN ] a
  where a.appln_kind = 'D2'
   ;
   
                                               
  SELECT  'minimum D2 publication id' , MIN(pat_publn_id) from
   [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where a.appln_kind = 'D2'
  and a.appln_id = b.appln_id
   ;
   
                                               
  SELECT  'maximum D2 publication id' , Max(pat_publn_id) from
   [TLS201_APPLN ] a
  ,[TLS211_pat_publn ] b
  where a.appln_kind = 'D2'
  and a.appln_id = b.appln_id
   ;
   
                                             