use patstatoct2011
go
  SELECT
      person_name
     ,person_address
     ,person_ctry_code         as PersCC
     ,appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,appln_filing_date        as AppFiling
     ,doc_std_name             as DocStdName
     ,applt_seq_nr             as AppSeq
     ,invt_seq_nr              as InvSeq
   FROM
   [TLS206_person   ] c
  ,[TLS201_appln      ] a
  ,[TLS207_pers_appln ] d
  ,[TLS208_doc_std_nms ] e
  where
      d.person_id = c.person_id
  and c.doc_std_name_id = e.doc_std_name_id
  and d.appln_id = a.appln_id
  and d.appln_id = (
   select distinct appln_id from
   [TLS211_pat_publn]
   where
        publn_auth = 'EP'
  and   publn_nr   = '        0086411'
                    )
  order by invt_seq_nr , person_name
  ;
        
        
  use patstatapril2011
go
  SELECT
      person_name
     ,person_address
     ,person_ctry_code         as PersCC
     ,appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,appln_filing_date        as AppFiling
     ,doc_std_name             as DocStdName
     ,applt_seq_nr             as AppSeq
     ,invt_seq_nr              as InvSeq
   FROM
   [TLS206_person   ] c
  ,[TLS201_appln      ] a
  ,[TLS207_pers_appln ] d
  ,[TLS208_doc_std_nms ] e
  where
      d.person_id = c.person_id
  and c.doc_std_name_id = e.doc_std_name_id
  and d.appln_id = a.appln_id
  and d.appln_id = (
   select distinct appln_id from
   [TLS211_pat_publn]
   where
        publn_auth = 'EP'
  and   publn_nr   = '        0086411'
                    )
  order by invt_seq_nr , person_name
  ;
        
        
  