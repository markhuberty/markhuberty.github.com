--check if priorities are indicated

use patstatoct2011
go
SELECT a.[appln_id]
      ,[appln_auth]
      ,[appln_nr]
      ,[appln_kind]
      ,[appln_filing_date]
      ,[ipr_type]
      ,a.[appln_title_lg]
      ,[appln_abstract_lg]
      ,[internat_appln_id]
      --,[publn_lg]
      --,[publn_first_grant]
      --[APPLN_ID]
      ,[PRIOR_APPLN_ID]
      ,[PRIOR_APPLN_SEQ_NR]
  FROM tls201_appln a
 ,tls204_appln_prior b
  ,tls211_pat_publn c
  where publn_auth = 'EP'
  and publn_nr = '        2285130'
  and c.appln_id  = a.appln_id
  and a.appln_id = b.APPLN_ID
  --and a.appln_id in
GO


use patstatapril2011
go
SELECT  a.[appln_id]
      ,[appln_auth]
      ,[appln_nr]
      ,[appln_kind]
      ,[appln_filing_date]
      ,[ipr_type]
      ,a.[appln_title_lg]
      ,[appln_abstract_lg]
      ,[internat_appln_id]
      --,[publn_lg]
      --,[publn_first_grant]
      --[APPLN_ID]
      ,[PRIOR_APPLN_ID]
      ,[PRIOR_APPLN_SEQ_NR]
  FROM tls201_appln a
  ,tls204_appln_prior b
  ,tls211_pat_publn c
  where publn_auth = 'JP'
  and publn_nr = '     2009022020'
  and c.appln_id  = a.appln_id
  and a.appln_id = b.APPLN_ID
  --and a.appln_id in
GO


