-- Contrary to what one can expect, the numbers can be different over the PATSTAT releases, when application numbers have been corrected, re-keyed or simply deleted.
-- In those cases, a new appln_id can be assigned, so it is not so that all appln_id's from the previous release should appear in the newer release.
-- These applications (or also publications) can easily be detected with this code:

/*
use patstatapril2011
go
SELECT a.*
FROM [tls201_appln] a
WHERE (a.appln_auth+a.appln_nr+a.appln_kind) not in (select (c.publn_auth+c.publn_nr+c.publn_kind) from [patstatoct2011].[dbo].[tls211_pat_publn]c )
		and a.appln_id < 900000000
order by a.appln_auth,a.appln_nr,a.appln_kind
*/


use patstatoct2011
go
  SELECT 'Count all DE publications with publication year 2000: ',COUNT(*) FROM
   [TLS211_pat_publn]
  where publn_auth = 'DE'
  and publn_date between '2000-01-01' and '2000-12-31'
   ;
   SELECT  'Count all DE publications before 20100131 that have application kind code not D2:', COUNT(*)
   FROM [TLS211_PAT_PUBLN  ] a
      , [TLS201_APPLN  ] b
   WHERE A.PUBLN_AUTH = 'DE'
        AND A.APPLN_ID = B.APPLN_ID
        AND B.APPLN_KIND <> 'D2'
        
  and publn_date <  '2010-01-31'
   ;
   SELECT  'Count all DE publications before 20100131 -should be equal to above- :', COUNT(*)
   FROM [TLS211_PAT_PUBLN]
   WHERE   PUBLN_AUTH = 'DE'
  and publn_date <  '2010-01-31'
   ;
  SELECT 'DE - D2 applications: ', COUNT(*)
   FROM [TLS211_PAT_PUBLN  ] a
      , [TLS201_APPLN  ] b
   WHERE A.PUBLN_AUTH = 'DE'
        AND A.APPLN_ID = B.APPLN_ID
        AND B.APPLN_KIND = 'D2';

use patstatapril2011
go

  SELECT 'Count all DE publications with publication year 2000: ',COUNT(*) FROM
   [TLS211_pat_publn]
  where publn_auth = 'DE'
  and publn_date between '2000-01-01' and '2000-12-31'
   ;
   SELECT  'Count all DE publications before 20100131 that have application kind code not D2:', COUNT(*)
   FROM [TLS211_PAT_PUBLN  ] a
      , [TLS201_APPLN  ] b
   WHERE A.PUBLN_AUTH = 'DE'
        AND A.APPLN_ID = B.APPLN_ID
        AND B.APPLN_KIND <> 'D2'
        
  and publn_date <  '2010-01-31'
   ;
   SELECT  'Count all DE publications before 20100131 -should be equal to above- :', COUNT(*)
   FROM [TLS211_PAT_PUBLN]
   WHERE   PUBLN_AUTH = 'DE'
  and publn_date <  '2010-01-31'
   ;
  SELECT 'DE - D2 applications: ', COUNT(*)
   FROM [TLS211_PAT_PUBLN  ] a
      , [TLS201_APPLN  ] b
   WHERE A.PUBLN_AUTH = 'DE'
        AND A.APPLN_ID = B.APPLN_ID
        AND B.APPLN_KIND = 'D2';