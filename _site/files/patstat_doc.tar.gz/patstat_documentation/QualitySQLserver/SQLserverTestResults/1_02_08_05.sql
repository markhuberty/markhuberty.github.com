--0054-display-all-ECLA-rows-for-EP1000000
--Compare against GPI result or DACC
--Reported descripantie in GPI to EPAL
--EP 1000000 B1 20030212;   H02H 006/08, B28B 001/29, B28B 005/02B2, B28B 007/00F
--In GPI you will see H02P6/08; B28B1/29; B28B5/02B2; B28B7/00F in the notice view and NOT as above.
--ICO codes added from Sept2010



use patstatoct2011
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where publn_auth = 'EP'
  and (publn_nr = '        1000000' or publn_nr = '        2148557')
  and  a.appln_id = b.appln_id
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
GO

use patstatapril2011
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where publn_auth = 'EP'
  and (publn_nr = '        1000000' or publn_nr = '        2148557')
  and  a.appln_id = b.appln_id
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
GO




