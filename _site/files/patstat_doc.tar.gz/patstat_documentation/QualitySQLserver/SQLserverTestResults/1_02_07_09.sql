-- The query counts all D2 applications that are dubplicates.
-- Thest duplicates originate because they are linked to publications that have different kind codes.
-- We can assume that the kind codes of the publication are wrongly cited (by the applicant - examiner) resulting in duplicate D2 applications.
-- Asuming no major data cleaining is done, the number should only go slightly up compared to previous edtions.
-- To see the duplicates, remove the "count", the /* comment indicators and the -- in front of the order.

-- April 2011: (168606 row(s) affected)
-- October 2011: (166648 row(s) affected)


use patstatoct2011
go
SELECT 
count (a.appln_id) as patstatoct2011_count
    /* ,a.appln_auth a_b
     ,a.appln_nr a_c
     ,a.appln_kind a_d
     ,b.appln_id b_a
     ,b.appln_auth b_b
     ,b.appln_nr b_c
     ,b.appln_kind b_d
, c.* */
    FROM  [tls201_appln] a
  ,  [tls201_appln] b
  , tls211_pat_publn c
  where a.appln_kind = 'D2'
  and a.appln_auth = b.appln_auth
  and a.appln_nr = b.appln_nr
  and b.appln_kind = 'D2'
  and a.appln_id <> b.appln_id
  and a.appln_id = c.appln_id
 --  order by a.appln_auth, a.appln_nr, a.appln_kind
  
  use patstatapril2011
go
SELECT 
count (a.appln_id) patstatapril2011_count
 
   /*  ,a.appln_auth a_b
     ,a.appln_nr a_c
     ,a.appln_kind a_d
     ,b.appln_id b_a
     ,b.appln_auth b_b
     ,b.appln_nr b_c
     ,b.appln_kind b_d
, c.* */
 
    FROM  [tls201_appln] a
  ,  [tls201_appln] b
  , tls211_pat_publn c
  where a.appln_kind = 'D2'
  and a.appln_auth = b.appln_auth
  and a.appln_nr = b.appln_nr
  and b.appln_kind = 'D2'
  and a.appln_id <> b.appln_id
  and a.appln_id = c.appln_id
  -- order by a.appln_auth, a.appln_nr, a.appln_kind