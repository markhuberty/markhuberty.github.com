--0053-count-applications-with-EC-IDT-ICO-ECNO-excl-artificials (with duplicates for multiple classifications.)


use patstatoct2011 
go

SELECT	b.appln_auth ,
		a.epo_class_scheme,
		Count (b.appln_id) as 'Number of applications'

FROM	tls217_appln_ecla a,
		tls201_appln b
  where
      b.appln_id in (
						select appln_id from  tls217_appln_ecla
						where
							a.appln_id = b.appln_id
							and b.appln_filing_date <> '9999-12-31'
							and b.appln_auth in ('EP','WO','JP','US','DE','FR'))
  group by	b.appln_auth,
			a.epo_class_scheme				
  order by	b.appln_auth,
			a.epo_class_scheme;
			
;

use patstatapril2011 
go

SELECT	b.appln_auth ,
		a.epo_class_scheme,
		Count (b.appln_id) as 'Number of applications'

FROM	tls217_appln_ecla a,
		tls201_appln b
  where
      b.appln_id in (
						select appln_id from  tls217_appln_ecla
						where
							a.appln_id = b.appln_id
							and b.appln_filing_date <> '9999-12-31'
							and b.appln_auth in ('EP','WO','JP','US','DE','FR'))
  group by	b.appln_auth,
			a.epo_class_scheme				
  order by	b.appln_auth,
			a.epo_class_scheme;
			
;