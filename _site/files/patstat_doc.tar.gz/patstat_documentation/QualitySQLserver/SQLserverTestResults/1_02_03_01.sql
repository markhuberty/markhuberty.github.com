--remember to change max appln_id for non-artificial applications
-- changed maximum to 900.000.000 for patstat_april2011
-- changed maximum to 900.000.000 for patstat_oct2011
-- increase of about 100.000 seems to be the norm.

use patstatoct2011
go
  SELECT 'count TLS201_APPLN' , COUNT(*) FROM
 [TLS201_APPLN]
   where appln_id >= 900000000
and appln_kind <> 'D2'
--D2 is the kind code of artificial applications created from artificial
--cited publications
;
use patstatapril2011
go
  SELECT 'count TLS201_APPLN' , COUNT(*) FROM
 [TLS201_APPLN]
   where appln_id >= 900000000
and appln_kind <> 'D2'
--D2 is the kind code of artificial applications created from artificial
--cited publications
;
          