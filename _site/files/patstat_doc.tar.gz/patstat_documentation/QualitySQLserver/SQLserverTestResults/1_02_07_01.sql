-- Check if i increase in amount of D2 documents is reasonable.
-- April2009	1.239.563
-- Sept2009	1.249.406
-- April2010	1.252.476
-- Sept2010	1.274.345
-- April2011	1.692.290 ???
-- Sept2011	??


use patstatoct2011
go
  SELECT 'count TLS201_APPLN' , COUNT(*) FROM
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'min TLS201_APPLN' ,min (appln_id) from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'max TLS201_APPLN' ,max (appln_id)  from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

  use patstatapril2011
go
  SELECT 'count TLS201_APPLN' , COUNT(*) FROM
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'min TLS201_APPLN' ,min (appln_id) from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'max TLS201_APPLN' ,max (appln_id)  from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

use patstatapril2010
go
  SELECT 'count TLS201_APPLN' , COUNT(*) FROM
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'min TLS201_APPLN' ,min (appln_id) from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'max TLS201_APPLN' ,max (appln_id)  from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

use patstatsept2009
go
  SELECT 'count TLS201_APPLN' , COUNT(*) FROM
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'min TLS201_APPLN' ,min (appln_id) from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'max TLS201_APPLN' ,max (appln_id)  from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

use patstatapril2009
go
  SELECT 'count TLS201_APPLN' , COUNT(*) FROM
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'min TLS201_APPLN' ,min (appln_id) from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

   select 'max TLS201_APPLN' ,max (appln_id)  from
  [TLS201_APPLN]
  where appln_kind = 'D2'
   ;

  