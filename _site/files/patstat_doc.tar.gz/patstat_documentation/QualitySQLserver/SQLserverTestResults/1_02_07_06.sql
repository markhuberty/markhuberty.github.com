use patstatoct2011
go
SELECT *        FROM                     
 [TLS201_appln] a                  
,[TLS211_pat_publn] b              
where publn_auth = 'AT'                  
and publn_nr = '          45310'         
and a.appln_id = b.appln_id              
 ;                                       
                                         
SELECT                                   
   B.PAT_PUBLN_ID                        
  ,A.PUBLN_AUTH                          
  ,A.PUBLN_NR                            
  ,A.PUBLN_KIND                          
  ,B.CITN_ID                             
  ,B.CITED_PAT_PUBLN_ID                  
  ,B.NPL_PUBLN_ID                        
  ,B.PAT_CITN_SEQ_NR                     
  FROM [TLS211_pat_publn] A        
      ,[TLS212_citation] B         
  WHERE CITED_PAT_PUBLN_ID in (           
     SELECT PAT_PUBLN_ID  FROM           
      [TLS211_pat_publn]           
      WHERE PUBLN_AUTH = 'AT'            
      AND PUBLN_NR = '          45310'
                             )           
    AND B.PAT_PUBLN_ID =A.PAT_PUBLN_ID
    order by  publn_nr
 ;                                       
 use patstatapril2011
go
SELECT *        FROM                     
 [TLS201_appln] a                  
,[TLS211_pat_publn] b              
where publn_auth = 'AT'                  
and publn_nr = '          45310'         
and a.appln_id = b.appln_id              
 ;                                       
                                         
SELECT                                   
   B.PAT_PUBLN_ID                        
  ,A.PUBLN_AUTH                          
  ,A.PUBLN_NR                            
  ,A.PUBLN_KIND                          
  ,B.CITN_ID                             
  ,B.CITED_PAT_PUBLN_ID                  
  ,B.NPL_PUBLN_ID                        
  ,B.PAT_CITN_SEQ_NR                     
  FROM [TLS211_pat_publn] A        
      ,[TLS212_citation] B         
  WHERE CITED_PAT_PUBLN_ID in (           
     SELECT PAT_PUBLN_ID  FROM           
      [TLS211_pat_publn]           
      WHERE PUBLN_AUTH = 'AT'            
      AND PUBLN_NR = '          45310')           
    AND B.PAT_PUBLN_ID =A.PAT_PUBLN_ID  
    order by  publn_nr 
 ;                                       