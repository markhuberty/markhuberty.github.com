--Changed the oct2011 version to check against tls223_appln_docus
-- needs to be adapted again in April2012

use patstatoct2011
go
  SELECT
      appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,appln_filing_date        as AppFiling
     ,docus_class_symbol       as NatSymbol
   FROM
   [TLS201_appln      ] a
  ,[tls223_appln_docus] e
  where
      e.appln_id = a.appln_id
  and a.appln_id in (
   select distinct appln_id from
   [TLS211_pat_publn]
   where
        publn_auth = 'US'
  and   publn_nr   like  '        400000%'
                    )
    order by appln_auth , appln_nr
        ,    docus_class_symbol 
  ;
                
                -- note that from April 2010 , the US symbols
                --have often an X in the front

  SELECT
      appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,appln_filing_date        as AppFiling
     ,docus_class_symbol       as NatSymbol
   FROM
   [TLS201_appln      ] a
  ,[tls223_appln_docus ] e
  where
      e.appln_id = a.appln_id
  and a.appln_id in (
   select distinct appln_id from
   [TLS211_pat_publn]
   where
        publn_auth = 'US'
  and   publn_nr   like  '        500000%'
                    )
    order by appln_auth , appln_nr
        ,    docus_class_symbol
  ;
                     
use patstatapril2011
go
  SELECT
      appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,appln_filing_date        as AppFiling
     ,nat_class_symbol         as NatSymbol
   FROM
   [TLS201_appln      ] a
  ,[TLS210_appln_n_cls ] e
  where
      e.appln_id = a.appln_id
  and a.appln_id in (
   select distinct appln_id from
   [TLS211_pat_publn]
   where
        publn_auth = 'US'
  and   publn_nr   like  '        400000%'
                    )
    order by appln_auth , appln_nr
        ,    nat_class_symbol
  ;

  SELECT
      appln_auth               as AppCC
     ,appln_nr                 as AppNR
     ,appln_kind               as AppKD
     ,appln_filing_date        as AppFiling
     ,nat_class_symbol         as NatSymbol
   FROM
   [TLS201_appln      ] a
  ,[TLS210_appln_n_cls ] e
  where
      e.appln_id = a.appln_id
  and a.appln_id in (
   select distinct appln_id from
   [TLS211_pat_publn]
   where
        publn_auth = 'US'
  and   publn_nr   like  '        500000%'
                    )
    order by appln_auth , appln_nr
        ,    nat_class_symbol
  ;
                                    
  
                                    