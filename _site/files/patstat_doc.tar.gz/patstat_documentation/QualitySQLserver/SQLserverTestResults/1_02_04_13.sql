use patstatoct2011
go

 SELECT
       B.PERSON_ID
      ,B.APPLN_ID
      ,APPLT_SEQ_NR
      ,INVT_SEQ_NR
      ,PERSON_NAME
      ,PERSON_ADDRESS
       FROM [TLS206_PERSON] A
        ,   [TLS207_PERS_APPLN] B
        ,   [TLS211_PAT_PUBLN] C
          WHERE
        C.PUBLN_AUTH = 'US'
    AND C.PUBLN_NR   = '        7232754'
    AND C.APPLN_ID = B.APPLN_ID
    AND A.PERSON_ID = B.PERSON_ID
    order by applt_seq_nr,invt_seq_nr
   ;

 use patstatapril2011
go

 SELECT
       B.PERSON_ID
      ,B.APPLN_ID
      ,APPLT_SEQ_NR
      ,INVT_SEQ_NR
      ,PERSON_NAME
      ,PERSON_ADDRESS
       FROM [TLS206_PERSON] A
        ,   [TLS207_PERS_APPLN] B
        ,   [TLS211_PAT_PUBLN] C
          WHERE
        C.PUBLN_AUTH = 'US'
    AND C.PUBLN_NR   = '        7232754'
    AND C.APPLN_ID = B.APPLN_ID
    AND A.PERSON_ID = B.PERSON_ID
    order by applt_seq_nr,invt_seq_nr
   ;

 