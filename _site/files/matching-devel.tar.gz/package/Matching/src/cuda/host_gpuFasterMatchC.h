extern "C" void host_ith_master_loop(float *Tr, float *X, float *ww, int All, int N, long M, int xvars, float *ACTMAT, float *Mi, float *Wi_ratio, float cdd);

extern "C" void gpuCleanup(void);
