-- Checks if documents cited in ISR have citn_origin = 5--

use patstatoct2011
go

SELECT [citn_id]
      ,[cited_pat_publn_id]
      ,[npl_publn_id]
      ,[pat_citn_seq_nr]
      ,[npl_citn_seq_nr]
      ,[citn_origin]
      ,b.[publn_auth]
      ,   b.[publn_nr]
      ,  b.[publn_kind]
      ,c.publn_auth as citedcc
      ,c.publn_nr as citednr
      ,c.publn_kind as citedkd
      ,b.pat_publn_id
  FROM [patstatapril2011].[dbo].[tls212_citation] a
  ,  [patstatapril2011].[dbo].[tls211_pat_publn] b
  ,  [patstatapril2011].[dbo].[tls211_pat_publn] c
  where a.[pat_publn_id] = b.[pat_publn_id]
  and a.pat_publn_id < 50
  and c.pat_publn_id = a.cited_pat_publn_id
  and b.pat_publn_id = 35
  order by citn_origin desc;
                                       
use patstatapril2011
go 
 SELECT [citn_id]
      ,[cited_pat_publn_id]
      ,[npl_publn_id]
      ,[pat_citn_seq_nr]
      ,[npl_citn_seq_nr]
      ,[citn_origin]
      ,b.[publn_auth]
      ,   b.[publn_nr]
      ,  b.[publn_kind]
      ,c.publn_auth as citedcc
      ,c.publn_nr as citednr
      ,c.publn_kind as citedkd
      ,b.pat_publn_id
  FROM [patstatapril2011].[dbo].[tls212_citation] a
  ,  [patstatapril2011].[dbo].[tls211_pat_publn] b
  ,  [patstatapril2011].[dbo].[tls211_pat_publn] c
  where a.[pat_publn_id] = b.[pat_publn_id]
  and a.pat_publn_id < 50
  and c.pat_publn_id = a.cited_pat_publn_id
  and b.pat_publn_id = 35
  order by citn_origin desc
GO
;                                              
                            