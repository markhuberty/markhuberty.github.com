extern "C" void host_ith_master_loop(float *Tr, float *X, float *ww, int All, int N, long M, int xvars, float *ACTMAT, float *Mi, float *Wi_ratio, float cdd);

extern "C" void gpuCleanup(void);

__global__ void device_map_distance(float *gpu_tr, float *gpu_X, float *gpu_ww,  int gpu_N, int gpu_All, int gpu_xvars, float *gpu_Atomic_Dist);

__global__ void device_calc_distance(float *gpu_tr, float *gpu_X, float *gpu_ww, int gpu_N, int gpu_All, int gpu_xvars, int ct_tr, int ct_ctl, float *gpu_Dist);

__global__ void device_write_sort_matrix(int gpu_N, int gpu_M, float *gpu_tr, int ct_ctl, float *gpu_sortMatrix, float *gpu_Dist, float *gpu_DistMax);

__global__ void device_sort_distances(int gpu_N, int gpu_M, int ct_ctl, float *gpu_tr, float *gpu_DistMax, float *gpu_sortMatrix);

__global__ void device_get_matches(int gpu_N, float *gpu_tr, float *gpu_Dist, float *gpu_DistMax, float *gpu_Mi, float *gpu_Wi_ratio, float gpu_cdd);

__global__ void device_process_ACTMAT(float *gpu_Dist, float *gpu_Mi, float *gpu_Wi_ratio, int N, float *gpu_tr);

__device__ float gpu_kth_smallest(float *a, int n, int k, int idx);

float sum_vector(float *a, int size);
