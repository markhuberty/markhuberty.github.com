-- this document should always be a recent one , so cannot be compared against the previous database
-- sept2010  Changed publication numbers to recent numbers and added an A3 as last one.
--april 2011 adde subquery that automatically get the latest EP-A1 publications.  Change "Select TOP 5"  if you want to have more...
-- KEEP IN MIND that EP A1 publications that are translations from PCT in non EP languages (f.ex.: EP2210648) will NOT show the citations, even
-- though they are "printed" on the EP A1.  Esp@cent and register WILL show these citations.  NPL cited during examination will show (but not part of this test)

use patstatoct2011
go
  SELECT
      a.publn_auth             as PubCC
     ,a.publn_nr               as CitingPub
     ,a.publn_kind             as PubKD
     ,a.publn_date			   as PubDate	
     ,b.publn_auth             as PubCC
     ,b.publn_nr               as CitedPub
     ,b.publn_kind             as PubKD
   FROM
   [TLS211_pat_publn ] a
  ,[TLS211_pat_publn ] b
  ,[TLS212_citation  ] c
  where
      a.pat_publn_id = c.pat_publn_id
  and b.pat_publn_id = c.cited_pat_publn_id
  and a.pat_publn_id in (
   select          pat_publn_id from
   [TLS211_pat_publn]
   where
        publn_auth = 'EP'
  and   (  
	   publn_nr in ( SELECT TOP 5 
						[publn_nr]      
					  FROM tls211_pat_publn 
					  where publn_auth = 'EP'  and publn_kind = 'A1' and YEAR (publn_date) < 2020
					  order by publn_date desc)))

    order by
         a.publn_auth
        ,a.publn_nr
        ,a.publn_kind
        ,b.publn_auth
        ,b.publn_nr
        ,b.publn_kind
  ;