--0059-display-ICO-symbols
-- returns ?? docs - choose some with  y02 and compare agasint previous version (y01)
-- note in april2010 no Y02% symbols yet.... 
-- Changed query to look for Y01

-- Added 2 "publication number counts with counts of all ICO.s"
-- correctedt query to changed name for tls217, was still referring to ICO instead of ECLA.

use patstatoct2011 
go

SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  --b.appln_id between 15000000 and 15000040
    b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'EP'
  and publn_nr = '        0063397' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        0056056' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        0077577' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        2063268' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        1751299' )
  
--or pat_publn_id between 1000000 and 10000000
--   or publn_auth = 'EP' 
  )

  and  a.appln_id = b.appln_id
   and epo_class_scheme = 'ICO'
--   and epo_class_symbol like 'Y%'
     and epo_class_symbol like 'Y01%'
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
GO

-- include at least 3 different publications
--compare against Y01N  Nano from  patstatapril2011
-- check for EST fields...Y02N I think

-- Compare against GPI result or DACC

use patstatoct2011 
go

SELECT b.publn_auth, a.epo_class_symbol, count(a.appln_id)as 'Number of applications patstatoct2011'
 
  FROM  tls217_appln_ecla a,
        tls211_pat_publn b
  where
     a.appln_id = b.appln_id
   and epo_class_scheme = 'ICO'
   and epo_class_symbol like 'Y%'
   and b.publn_auth in ('US','JP', 'EP','WO','DE','CN')
  group by b.publn_auth, a.epo_class_symbol
  order by b.publn_auth,
           a.epo_class_symbol;

use patstatapril2011
go

SELECT b.publn_auth, a.epo_class_symbol, count(a.appln_id)as 'Number of applications patstatapril2011' 
 
  FROM  tls217_appln_ecla a,
        tls211_pat_publn b
  where
     a.appln_id = b.appln_id
     and epo_class_symbol like 'Y%'
     and b.publn_auth in ('US','JP', 'EP','WO','DE','CN')
  group by b.publn_auth, a.epo_class_symbol
  order by b.publn_auth,
           a.epo_class_symbol;
           

use patstatapril2011 
go

SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  --b.appln_id between 15000000 and 15000040
    b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'EP'
  and publn_nr = '        0063397' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        0056056' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        0077577' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        2063268' )
  or 
   (publn_auth = 'EP'
  and publn_nr = '        1751299' )
  
--or pat_publn_id between 1000000 and 10000000
--   or publn_auth = 'EP' 
  )

  and  a.appln_id = b.appln_id
   and epo_class_scheme = 'ICO'
--   and epo_class_symbol like 'Y%'
     and epo_class_symbol like 'Y01%'
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
GO

-- include at least 3 different publications
--compare against Y01N  Nano from  patstatapril2011
-- check for EST fields...Y02N I think

-- Compare against GPI result or DACC

use patstatoct2011
go

SELECT b.publn_auth, a.epo_class_symbol, count(a.appln_id)as 'Number of applicatoins patstatoct2011'
 
  FROM  tls217_appln_ecla a,
        tls211_pat_publn b
  where
     a.appln_id = b.appln_id
   and epo_class_scheme = 'ICO'
   and epo_class_symbol like 'Y%'
   and b.publn_auth in ('US','JP', 'EP','WO','DE','CN')
  group by b.publn_auth, a.epo_class_symbol
  order by b.publn_auth,
           a.epo_class_symbol;

use patstatapril2011
go

SELECT b.publn_auth, a.epo_class_symbol, count(a.appln_id)as 'Number of applications patstatapril2011' 
 
  FROM  tls217_appln_ecla a,
        tls211_pat_publn b
  where
     a.appln_id = b.appln_id
     and epo_class_scheme = 'ICO'
     and epo_class_symbol like 'Y%'
     and b.publn_auth in ('US','JP', 'EP','WO','DE','CN')
  group by b.publn_auth, a.epo_class_symbol
  order by b.publn_auth,
           a.epo_class_symbol
           ;