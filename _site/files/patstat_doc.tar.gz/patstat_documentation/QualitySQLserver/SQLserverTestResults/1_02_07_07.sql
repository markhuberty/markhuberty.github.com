--Looks for documents citing AT45310

--Comparing with esp@cenet if citations for AT45310A correct.

use patstatoct2011
go 
 SELECT                                         
   a.publn_auth                                
  ,a.publn_nr                                  
  ,a.publn_kind                                
  ,a.publn_date                                
  from [TLS211_pat_publn] a              
  ,    [TLS212_citation] b               
  where cited_pat_publn_id in (                
     SELECT pat_publn_id  from                 
      [TLS211_pat_publn] c               
      where c.publn_auth = 'AT'                
      and   c.publn_nr = '          45310'     
                     
                             )                 
  and a.pat_publn_id = b.pat_publn_id          
 ;                                             
SELECT                                         
   a.publn_auth                                
  ,a.publn_nr                                  
  ,a.publn_kind                                
  ,a.publn_date                                
  from [TLS211_pat_publn] a              
  ,    [TLS212_citation] b               
  where cited_pat_publn_id in (                
     SELECT pat_publn_id  from                 
      [TLS211_pat_publn] c               
      where c.publn_auth = 'AT'                
      and   c.publn_nr = '          45310'     
                             )                 
  and a.pat_publn_id = b.pat_publn_id          
 ;                                             
 use patstatapril2011
go 
 SELECT                                         
   a.publn_auth                                
  ,a.publn_nr                                  
  ,a.publn_kind                                
  ,a.publn_date                                
  from [TLS211_pat_publn] a              
  ,    [TLS212_citation] b               
  where cited_pat_publn_id in (                
     SELECT pat_publn_id  from                 
      [TLS211_pat_publn] c               
      where c.publn_auth = 'AT'                
      and   c.publn_nr = '          45310'     
                   
                             )                 
  and a.pat_publn_id = b.pat_publn_id          
 ;                                             
SELECT                                         
   a.publn_auth                                
  ,a.publn_nr                                  
  ,a.publn_kind                                
  ,a.publn_date                                
  from [TLS211_pat_publn] a              
  ,    [TLS212_citation] b               
  where cited_pat_publn_id in (                
     SELECT pat_publn_id  from                 
      [TLS211_pat_publn] c               
      where c.publn_auth = 'AT'                
      and   c.publn_nr = '          45310'     
                             )                 
  and a.pat_publn_id = b.pat_publn_id          
 ;                                              
                            