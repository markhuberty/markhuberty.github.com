-- Test characterset on 2 German, 2 French and 2 Spanish abstracts; check if words/characters are correct: 
-- �bersch�ssigen, Einzelkorns�maschine, Aussaat�ffnungen, trichterf�rmigen, 
-- ajour�, lumi�re port�e,
-- sujeci�n,protecci�ncl�nico y/o quir�rgico, 

use patstatoct2011
go
  SELECT a.publn_auth,a.publn_nr, a.publn_kind, a.publn_date, b.appln_abstract
   FROM
   TLS203_APPLN_abstr  b,
   TLS211_PAT_PUBLN  a
     where a.appln_id = b.appln_id
     and 
    ( (a.publn_auth ='ep' AND a.publn_nr ='        2210464')
     or  (a.publn_auth ='ep' AND a.publn_nr ='        2210465')
     or  (a.publn_auth ='ep' AND a.publn_nr ='        2211391')
     or  (a.publn_auth ='ep' AND a.publn_nr ='        2210496')
     or  (a.publn_auth ='es' AND a.publn_nr ='        1072384')
     or  (a.publn_auth ='es' AND a.publn_nr ='        1072385'))
     
     ;
     
     use patstatapril2011
go
  SELECT a.publn_auth,a.publn_nr, a.publn_kind, a.publn_date, b.appln_abstract
   FROM
   TLS203_APPLN_abstr  b,
   TLS211_PAT_PUBLN  a
     where a.appln_id = b.appln_id
     and 
    ( (a.publn_auth ='ep' AND a.publn_nr ='        2210464')
     or  (a.publn_auth ='ep' AND a.publn_nr ='        2210465')
     or  (a.publn_auth ='ep' AND a.publn_nr ='        2211391')
     or  (a.publn_auth ='ep' AND a.publn_nr ='        2210496')
     or  (a.publn_auth ='es' AND a.publn_nr ='        1072384')
     or  (a.publn_auth ='es' AND a.publn_nr ='        1072385'))
     
     ;