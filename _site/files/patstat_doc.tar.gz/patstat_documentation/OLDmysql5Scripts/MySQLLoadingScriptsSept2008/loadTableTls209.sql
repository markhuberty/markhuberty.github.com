-- This runs a set of scripts to load a database table
--
--
-- Version March2008    Created by Tony Teculescu    on 04/03/2008    
--

alter table TLS209_APPLN_IPC disable keys;
load data local infile '<enter path of unzipped files here>\\tls209_part01.txt' into table TLS209_APPLN_IPC fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls209_part02.txt' into table TLS209_APPLN_IPC fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls209_part03.txt' into table TLS209_APPLN_IPC fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls209_part04.txt' into table TLS209_APPLN_IPC fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls209_part05.txt' into table TLS209_APPLN_IPC fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls209_part06.txt' into table TLS209_APPLN_IPC fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls209_part07.txt' into table TLS209_APPLN_IPC fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls209_part08.txt' into table TLS209_APPLN_IPC fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls209_part09.txt' into table TLS209_APPLN_IPC fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
alter table TLS209_APPLN_IPC enable keys;
