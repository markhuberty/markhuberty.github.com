--automaticall gets recently published US application
--It checks the details for a recently published US application


use patstatoct2011 
go

select
                                            
  A.APPLN_ID                                        
, B.PERSON_ID                                       
, B.DOC_STD_NAME_ID                                 
, C.APPLT_SEQ_NR AS APP                             
, C.INVT_SEQ_NR AS INV                              
, e.publn_auth as PubCC                             
, e.publn_nr   as PubNR                             
, e.publn_kind as PubKD                             
, SUBSTRing(B.PERSON_NAME,1,25) AS PersonNAMEtruncated 
, SUBSTRing(B.PERSON_ADDRESS,1,100) as Person_address                                 
, SUBSTRing(D.DOC_STD_NAME,1,25) AS DocStandardNAME    
, B.PERSON_CTRY_CODE                                
       FROM [TLS201_APPLN ]     A             
       ,    [TLS206_PERSON ]    B             
       ,    [TLS207_PERS_APPLN ] C             
       ,    [TLS208_DOC_STD_NMS ] D            
       ,    [TLS211_pat_publn ]  E                
WHERE                                               
                                                    

  e.publn_nr in(SELECT TOP 3 [publn_nr]
					   FROM tls211_pat_publn
					   where publn_auth = 'US' and YEAR(publn_date) = year(getdate()) and publn_first_grant = 1
					   order by publn_date desc)
AND A.APPLN_ID  = C.APPLN_ID                        
AND A.APPLN_ID  = e.APPLN_ID                        
AND C.PERSON_ID = B.PERSON_ID                       
AND B.DOC_STD_NAME_ID =D.DOC_STD_NAME_ID            
ORDER BY  PersonNAMEtruncated                       
        , A.APPLN_ID                                
        , C.INVT_SEQ_NR                             
        , C.APPLT_SEQ_NR                            
        ;                                           
             

use patstatapril2011 
go

select
                                            
  A.APPLN_ID                                        
, B.PERSON_ID                                       
, B.DOC_STD_NAME_ID                                 
, C.APPLT_SEQ_NR AS APP                             
, C.INVT_SEQ_NR AS INV                              
, e.publn_auth as PubCC                             
, e.publn_nr   as PubNR                             
, e.publn_kind as PubKD                             
, SUBSTRing(B.PERSON_NAME,1,25) AS PersonNAMEtruncated 
, SUBSTRing(B.PERSON_ADDRESS,1,100) as Person_address                               
, SUBSTRing(D.DOC_STD_NAME,1,25) AS DocStandardNAME    
, B.PERSON_CTRY_CODE                                
       FROM [TLS201_APPLN ]     A             
       ,    [TLS206_PERSON ]    B             
       ,    [TLS207_PERS_APPLN ] C             
       ,    [TLS208_DOC_STD_NMS ] D            
       ,    [TLS211_pat_publn ]  E                
WHERE                                               
                                                    
--A.APPLN_AUTH     in ('US')   
--64476653	US	     2009175876	A1                            
--AND e.pat_publn_id = (64476653  )
  e.publn_auth = 'US'    
and e.publn_nr = '     2009325412'
AND A.APPLN_ID  = C.APPLN_ID                        
AND A.APPLN_ID  = e.APPLN_ID                        
AND C.PERSON_ID = B.PERSON_ID                       
AND B.DOC_STD_NAME_ID =D.DOC_STD_NAME_ID            
ORDER BY  PersonNAMEtruncated                       
        , A.APPLN_ID                                
        , C.INVT_SEQ_NR                             
        , C.APPLT_SEQ_NR                            
        ;                                           
             
