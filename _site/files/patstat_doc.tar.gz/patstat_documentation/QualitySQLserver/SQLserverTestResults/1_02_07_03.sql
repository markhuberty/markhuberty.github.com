-- count duplicate entries where kind code = D2 (artificial applications
-- resulting from artificial publications resulting from
-- cited docuemnts I cannot find in tls211
use patstatoct2011
go

SELECT  count(*)
-- a.appln_id
--      ,a.appln_auth
--      ,a.appln_nr
--      ,a.appln_kind
--      ,a.appln_filing_date
--      ,a.ipr_type
--      ,a.appln_title_lg
--      ,a.appln_abstract_lg
--      ,a.internat_appln_id
  FROM  [tls201_appln] a
  ,  [tls201_appln] b
  where a.appln_kind = 'D2'
  and a.appln_auth = b.appln_auth
  and a.appln_nr = b.appln_nr
  and b.appln_kind = 'D2'
  and a.appln_id <> b.appln_id
GO
use patstatapril2011
go

SELECT count(*) 

-- a.appln_id
--      ,a.appln_auth
--      ,a.appln_nr
--      ,a.appln_kind
--      ,a.appln_filing_date
--      ,a.ipr_type
--      ,a.appln_title_lg
--      ,a.appln_abstract_lg
--      ,a.internat_appln_id
    FROM  [tls201_appln] a
  ,  [tls201_appln] b
  where a.appln_kind = 'D2'
  and a.appln_auth = b.appln_auth
  and a.appln_nr = b.appln_nr
  and b.appln_kind = 'D2'
  and a.appln_id <> b.appln_id
GO


