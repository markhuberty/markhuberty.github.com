#define M(ROW,COL,NCOLS) (((ROW)*(NCOLS))+(COL))
//#define TOL 0.0000000001
#define TOL 0.000001f

#define DOUBLE_XMAX_CHECK DOUBLE_XMAX/1000 - 1000

/* Use CBLAS and Nate Optimizations. Note that uses of BLAS in
   FasterMatchC() and FastMatchC() also requires that
   __GenMatchBLAS__ is also defined in matching.cc
*/
#define __NBLAS__

// my function declarations
float sum (const Matrix & A);
float min_scalar (float a, float b);
float max_scalar (float a, float b);
Matrix multi_scalar (Matrix a, Matrix b);
Matrix col_assign (Matrix a, Matrix b, long col);
Matrix row_assign (Matrix a, Matrix b, long row);
Matrix diagCreate (Matrix a);
Matrix EqualityTestScalar(Matrix a, float s);
Matrix EqualityTestMatrix(Matrix a, Matrix s);
Matrix GreaterEqualTestScalar(Matrix a, long s);
Matrix LessEqualTestScalar(Matrix a, float s);
Matrix VectorAnd(Matrix a, Matrix b);
Matrix cumsum(Matrix a);
void display(Matrix A);




