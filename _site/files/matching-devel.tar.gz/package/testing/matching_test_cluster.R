## Mark Huberty
## 6 June 2010
## Code to test the new GenMatch function
library(Matching,
        #lib.loc="~/library/",
        lib.loc="~/Documents/Technology/gpuGenMatch/library",
        verbose=TRUE
        )
## Bring in the data
data(lalonde)

lalonde2 <- rbind(lalonde, lalonde)
lalonde3 <- rbind(lalonde, lalonde, lalonde)
lalonde4 <- rbind(lalonde2, lalonde2)

lalonde.list <- list(lalonde, lalonde2, lalonde3, lalonde4)

##set.seed(500)
#vec <- sample(1:dim(lalonde)[1], 100, replace=TRUE)
#lalonde.short <- lalonde[vec,]
#attach(lalonde.list)

lapply(1:length(lalonde.list), function(y){
#The covariates we want to match on
  data <- as.data.frame(lalonde.list[[y]])
  attach(data)
  X = cbind(age, educ, black, hisp, married, nodegr, u74, u75, re75, re74);

  ## Benchmarking
  N <- 5
  seed <- 1254
  pl <- 1

  print("Starting timing for beta=FALSE")
  genout.old.timing <- sapply(1:N, function(x){ 
    
    set.seed(seed)
    out <- system.time(GenMatch(Tr=treat,
                                X=X,
                                beta=FALSE,
                                ties=TRUE,
                                unif.seed=seed,
                                print.level=pl
                                )
                       )
    return(out)
    
  }
                              )           

  #save(genout.old.timing, file=paste("genout.old.timing", y, ".RData", sep=""))

  print("Starting timing for beta=TRUE")
  

  genout.new.timing <- sapply(1:N, function(x){
    
    set.seed(seed)
    out <- system.time(GenMatch(Tr=treat,
                                X=X,
                                beta=TRUE,
                                ties=TRUE,
                                unif.seed=seed,
                                print.level=pl
                                )
                       )
    
    return(out)
  }
                              )

  detach(data)
  save(genout.old.timing, genout.new.timing, file=paste("genout", y, ".RData", sep=""))
     }
  )

save.image("matching-devel-timing.RData")
