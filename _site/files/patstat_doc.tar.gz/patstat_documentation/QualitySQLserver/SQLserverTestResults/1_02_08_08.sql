--0057-display-EC-symbols
-- include at least 10 different publications
-- Compare against GPI result or DACC

use patstatoct2011
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind,pat_publn_id
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'EP'
  and publn_nr = '        1000000' )
  or 
   (publn_auth = 'US'
  and publn_nr = '        4000000' )  or 
   (publn_auth = 'EP'
  and publn_nr = '        2000000' )  or 
   (publn_auth = 'JP'
  and publn_nr = '     2003521226' )  or 
   (pat_publn_id in ( 10000000,20000000,3000000,35000000, 45000000, 50000000
                     ,55000000,60000000,6200000,66000000  ))
  )
  and  a.appln_id = b.appln_id
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
GO

;

use patstatapril2011
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind,pat_publn_id
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
  b.appln_id in (
  select appln_id from  tls211_pat_publn
  where
   (publn_auth = 'EP'
  and publn_nr = '        1000000' )
  or 
   (publn_auth = 'US'
  and publn_nr = '        4000000' )  or 
   (publn_auth = 'EP'
  and publn_nr = '        2000000' )  or 
   (publn_auth = 'JP'
  and publn_nr = '     2003521226' )  or 
   (pat_publn_id in ( 10000000,20000000,3000000,35000000, 45000000, 50000000
                     ,55000000,60000000,6200000,66000000  ))
  )
  and  a.appln_id = b.appln_id
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
GO

;
