## Mark Huberty
## 6 June 2010
## Code to test the new GenMatch function

setwd("~/Documents/Technology/gpuGenMatch/GenMatch/testing/")

library(Matching,
        #lib.loc="~/library/",
        lib.loc="library",
        verbose=TRUE
        )
## Bring in the data
data(lalonde)

##set.seed(500)
#vec <- sample(1:dim(lalonde)[1], 100, replace=TRUE)
#lalonde.short <- lalonde[vec,]
#attach(lalonde.list)
 
N <- 200
seed <- 38212
pl <- 0
rowcount <- dim(lalonde)[1]

equivalence.test <- lapply(10:N, function(y){

  ## Set the data to the right size
  data <- lalonde[c(1:y, (rowcount-y-1):rowcount),]

  attach(data)
  X = cbind(age, educ, black, hisp, married, nodegr, u74, u75, re75, re74);



  genout.orig <- GenMatch(Tr=treat,
                          X=X,
                          gpu=FALSE,
                          ties=TRUE,
                          unif.seed=seed,
                          print.level=pl
                          )
  genout.gpu <- GenMatch(Tr=treat,
                         X=X,
                         gpu=TRUE,
                         ties=TRUE,
                         unif.seed=seed,
                         print.level=pl
                         )

  test <- genout.orig$Weight.matrix == genout.gpu$Weight.matrix
  test <- sum(diag(test))/length(diag(test))

  dimdata <- dim(data)
  print(paste("For data of dim", dimdata[1], ":", test))

  detach(data)
  return(test)
  
}
                           )

save.image("matching-devel-timing.RData")
