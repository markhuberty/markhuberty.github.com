--for this one, you need to modify the line 
-- and e.publn_nr = '        7474732'  (Geert: changed to IN and selected a couple of publications)
-- to get a recently published US grant and it will only work on the new database. 
--It checks the details for a recently published US grant
-- sept2010 used US publications from 29/07/2010: 2010186134, 2010186135, 2010186136
-- october2011 used use publications from 

-- little improvement on the query, ...autopilot..., query gets the recent granted US by itself... and double check if recent is recent.


use patstatoct2011
go
     SELECT
       A.APPLN_ID
     , B.PERSON_ID
     , B.DOC_STD_NAME_ID
     , C.APPLT_SEQ_NR AS APP
     , C.INVT_SEQ_NR AS INV
     , e.publn_auth as PubCC
     , e.publn_nr   as PubNR
     , e.publn_kind as PubKD
     ,e.publn_date as PubDate
     , SUBSTRING(B.PERSON_NAME,1,50) AS PersonNAMEtruncated
     , SUBSTRING (B.PERSON_ADDRESS,1,70) person_address
     , SUBSTRING(D.DOC_STD_NAME,1,50) AS DocStandardNAME
     , B.PERSON_CTRY_CODE
            FROM [tls201_APPLN ]      A
            ,    [tls206_PERSON ]     B
            ,    [tls207_PERS_APPLN ] C
            ,    [tls208_DOC_STD_NMS ] D
            ,    [tls211_pat_publn ]   E
     WHERE
  --
     A.APPLN_AUTH = 'US'
     AND e.publn_nr in(SELECT TOP 3 [publn_nr]
					   FROM tls211_pat_publn
					   where publn_auth = 'US' and YEAR(publn_date) = year(getdate()) and publn_first_grant = 1
					   order by publn_date desc)
     AND A.APPLN_ID  = C.APPLN_ID
     AND A.APPLN_ID  = e.APPLN_ID
     AND C.PERSON_ID = B.PERSON_ID
     AND B.DOC_STD_NAME_ID =D.DOC_STD_NAME_ID
     ORDER BY  e.publn_nr
     
     
     use patstatapril2011
go
     SELECT
       A.APPLN_ID
     , B.PERSON_ID
     , B.DOC_STD_NAME_ID
     , C.APPLT_SEQ_NR AS APP
     , C.INVT_SEQ_NR AS INV
     , e.publn_auth as PubCC
     , e.publn_nr   as PubNR
     , e.publn_kind as PubKD
     ,e.publn_date as PubDate
     , SUBSTRING(B.PERSON_NAME,1,50) AS PersonNAMEtruncated
     , SUBSTRING (B.PERSON_ADDRESS,1,70) person_address
     , SUBSTRING(D.DOC_STD_NAME,1,50) AS DocStandardNAME
     , B.PERSON_CTRY_CODE
            FROM [tls201_APPLN ]      A
            ,    [tls206_PERSON ]     B
            ,    [tls207_PERS_APPLN ] C
            ,    [tls208_DOC_STD_NMS ] D
            ,    [tls211_pat_publn ]   E
     WHERE
  --
     A.APPLN_AUTH = 'US'
     AND e.publn_nr in(SELECT TOP 3 [publn_nr]
					   FROM tls211_pat_publn
					   where publn_auth = 'US' and YEAR(publn_date) = year(getdate()) and publn_first_grant = 1
					   order by publn_date desc)
     AND A.APPLN_ID  = C.APPLN_ID
     AND A.APPLN_ID  = e.APPLN_ID
     AND C.PERSON_ID = B.PERSON_ID
     AND B.DOC_STD_NAME_ID =D.DOC_STD_NAME_ID
     ORDER BY  e.publn_nr
     