/********************************************
* Create table for extended peson ASCII data - STEP 2
*
* For: MS SQL Server 2005 / 2008
* 
* Add new attributes to table tls206_ascii and populate them.
*
********************************************/

USE [patstatapril2011]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
Add new attributes
*/

ALTER TABLE [dbo].[tls206_ascii]
  ADD  
  last_name		varchar(500)	NULL, 
  first_name	varchar(255)	NULL,
  middle_names	varchar(255)	NULL,
  street		varchar(500)	NULL,  
  city			varchar(255)	NULL,
  state			varchar(255)	NULL,
  zip_code		varchar(255)	NULL 
GO

/*
Populate the new attributes
*/
update tls206_ascii
set 
last_name		= substring(name_addr, 1, last_name_len),
first_name		= substring(name_addr, 1+ last_name_len,  first_name_len),
middle_names	= substring(name_addr, 1+ last_name_len + first_name_len,  middle_names_len),
street			= substring(name_addr, 1+ last_name_len + first_name_len + middle_names_len,  street_len),
city			= substring(name_addr, 1+ last_name_len + first_name_len + middle_names_len + street_len,  city_len),
state			= substring(name_addr, 1+ last_name_len + first_name_len + middle_names_len + street_len + city_len,  state_len),
zip_code		= substring(name_addr, 1+ last_name_len + first_name_len + middle_names_len + street_len + city_len + state_len, zip_code_len)



-- Optional: Create an index on attribute person_id
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tls206_ascii]') AND name = N'IX_tls206_ext_person_id')
DROP INDEX [IX_tls206_ext_person_id] ON [dbo].[tls206_ascii] WITH ( ONLINE = OFF )
GO

CREATE NONCLUSTERED INDEX [IX_tls206_ext_person_id] ON [dbo].[tls206_ascii] 
([person_id] ASC) WITH
(PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
