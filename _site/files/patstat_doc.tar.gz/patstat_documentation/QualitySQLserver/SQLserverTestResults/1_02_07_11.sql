 -- According to the data catalog (6.6.3) artificial entries for citations should have application and publication date set to 9999.
 -- This test counts all the artificial publications that have a 9999 date.
 -- Check if numbers have not gone up dramatically compared to previous release. (Especially linked to certain countries.)
 
 /* publn_Auth	results_patstatoct2011		results_patstatapril2011
		WO	9999	11335		WO	9999	6721
		US	9999	199532		US	9999	143291
		TW	9999	7685		TW	9999	5519    */

 
 
 use patstatoct2011
 go
 
 SELECT  a.publn_Auth, YEAR(publn_date), COUNT(a.pat_publn_id)results_patstatoct2011
   FROM [TLS211_PAT_PUBLN  ] a
      , [TLS201_APPLN  ] b
   WHERE A.APPLN_ID = B.APPLN_ID
        AND B.APPLN_KIND = 'D2'
        and publn_date =  '9999-12-31'
 group by a.publn_Auth, YEAR(publn_date)
 order by publn_auth desc, YEAR(publn_date) desc
   ;
   
   use patstatapril2011
 go
 
 SELECT  a.publn_Auth, YEAR(publn_date), COUNT(a.pat_publn_id) results_patstatapril2011
   FROM [TLS211_PAT_PUBLN  ] a
      , [TLS201_APPLN  ] b
   WHERE A.APPLN_ID = B.APPLN_ID
        AND B.APPLN_KIND = 'D2'
        and publn_date =  '9999-12-31'
 group by a.publn_Auth, YEAR(publn_date)
 order by publn_auth desc, YEAR(publn_date) desc
   ;