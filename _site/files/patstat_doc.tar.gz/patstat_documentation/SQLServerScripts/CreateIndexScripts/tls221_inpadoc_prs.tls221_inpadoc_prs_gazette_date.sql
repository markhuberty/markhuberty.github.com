USE [patstatoct2011]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tls221_inpadoc_prs]') AND name = N'tls221_inpadoc_prs_gazette_date')
DROP INDEX [tls221_inpadoc_prs_gazette_date] ON [dbo].[tls221_inpadoc_prs] WITH ( ONLINE = OFF )
GO

CREATE NONCLUSTERED INDEX [tls221_inpadoc_prs_gazette_date] ON [dbo].[tls221_inpadoc_prs] 
(
	[prs_gazette_date] ASC,
	[appln_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]
GO

