-- This script fixes the date fields in the patstatrequest 
-- by converting the loaded strings in the date format.
--
--
-- Version June2008    Created by Tony Teculescu    on 04/03/2008    
--


-- Now fix the date in tls201_appln

ALTER TABLE `tls201_appln`
ADD COLUMN   appln_filing_date date after appln_filing_date_str;

UPDATE `tls201_appln` SET appln_filing_date = str_to_date(appln_filing_date_str, '%Y/%m/%d');

ALTER TABLE `tls201_appln`
ADD INDEX (appln_filing_date);

ALTER TABLE `tls201_appln`
DROP COLUMN appln_filing_date_str;

-- Now fix the date in tls209_appln_ipc

ALTER TABLE `tls209_appln_ipc`
ADD COLUMN   ipc_version date after ipc_version_str;

UPDATE `tls209_appln_ipc` SET ipc_version = str_to_date(ipc_version_str, '%Y/%m/%d');

ALTER TABLE `tls209_appln_ipc`
DROP COLUMN ipc_version_str;

-- Now fix the date in tls211_pat_publn

ALTER TABLE `tls211_pat_publn`
ADD COLUMN   publn_date date after publn_date_str;

UPDATE `tls211_pat_publn` SET publn_date = str_to_date(publn_date_str, '%Y/%m/%d');

ALTER TABLE `tls211_pat_publn`
ADD INDEX (publn_date);

ALTER TABLE `tls211_pat_publn`
DROP COLUMN publn_date_str;

