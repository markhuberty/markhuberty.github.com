/********************************************
* This is the script to create an empty table tls206_ASCII - STEP 1.
* It has been tested on MS SQL server 2008.
* After running STEP1 the table will be filled with dts-script.
* Then run STEP2 to create columns in name_addr field.
* Thanks to Martin Kracker - AT patent office - for this script.
********************************************/
USE [patstatapril2011]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

if object_id('dbo.tls206_ascii') IS NOT NULL
   DROP TABLE tls206_ascii
GO


CREATE TABLE dbo.tls206_ascii(
	person_id	int		NOT NULL, 
	doc_sn_id	int		NOT NULL,
	appln_id	int		NOT NULL,
	wk_country	varchar(7)	NULL,
	wk_number	varchar(10) 	NULL,
	wk_kind		varchar(2)	NULL,
	source		varchar(4)	NULL,
	a_i_flag	varchar(1)	NULL,
	seq_nr		smallint	NULL,
	country		varchar(2)	NULL,
	nationality 	varchar(2)	NULL,
	residence	varchar(2)	NULL,
	uspto_role	varchar(2)	NULL,
	last_name_len	int		NULL,
	first_name_len	int		NULL,
	middle_names_len int		NULL,
	street_len	int		NULL,
	city_len	int		NULL,
	state_len	int		NULL,
	zip_code_len	int		NULL,
	name_addr	varchar(439)	NULL )

;