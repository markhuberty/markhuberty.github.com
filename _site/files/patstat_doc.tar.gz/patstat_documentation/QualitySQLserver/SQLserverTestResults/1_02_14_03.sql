-- counts the number of distinc JP class symnbols.
-- 
/* jp_class_scheme	number_of_symbols_patatoctober2011
	FTERM	483657
	FI   	457104    */
	
	
use patstatoct2011
go
SELECT 
      jp_class_scheme, COUNT(distinct(jp_class_symbol)) as number_of_symbols_patstatoctober2011
FROM dbo.tls222_appln_jp_class
group by jp_class_scheme;

use patstatapril2011
go
SELECT 
      jp_class_scheme, COUNT(distinct(jp_class_symbol)) as number_of_symbols_patstatapril2011
FROM dbo.tls222_appln_jp_class
group by jp_class_scheme;