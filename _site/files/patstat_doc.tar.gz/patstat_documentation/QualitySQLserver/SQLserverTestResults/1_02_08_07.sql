--0056-display-IDT-symbols
use patstatoct2011 
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
   ((b.publn_auth = 'fr'
   and ( b.publn_date = '20041112') or Year(b.publn_date) = '2010'))
  and  a.appln_id = b.appln_id
  and  epo_class_scheme = 'IDT'
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
;

use patstatapril2011 
go
SELECT a.appln_id
    ,publn_auth ,publn_nr,publn_kind
    , publn_date
      ,[epo_class_auth]
      ,[epo_class_scheme]
      ,[epo_class_symbol]
  FROM [tls217_appln_ecla] a
  ,   tls211_pat_publn b
  where
   ((b.publn_auth = 'fr'
   and ( b.publn_date = '20041112') or Year(b.publn_date) = '2010'))
  and  a.appln_id = b.appln_id
  and  epo_class_scheme = 'IDT'
  order by publn_auth, publn_nr , publn_kind
      ,epo_class_auth
      ,epo_class_scheme
      ,epo_class_symbol
;



---Compare against GPI result or DACC

