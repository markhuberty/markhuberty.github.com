use patstatoct2011
go
SELECT a.[appln_id]
      ,[appln_auth]
      ,[appln_nr]
      ,[publn_nr]
      , publn_kind
      ,[appln_kind]
      ,[appln_title]
    --  ,appln_abstract
      ,[appln_title_lg]
      ,[appln_abstract_lg]
  FROM [tls201_appln] a
 -- , [tls203_appln_abstr] b
  , [tls202_appln_title] c
  ,[tls211_pat_publn] d
  where publn_auth = 'EP'
  and publn_nr in ( '        1000000'
                   , '        1000001'
                   , '        1000002'
                   , '        1000003'
                   , '        1000004'
                   )
  and a.appln_id = d.appln_id
  --and a.appln_id = b.appln_id
  and a.appln_id = c.appln_id
  order by appln_id
  
GO
use patstatapril2011
go
SELECT a.[appln_id]
      ,[appln_auth]
      ,[appln_nr]
      ,[publn_nr]
      , publn_kind
      ,[appln_kind]
      ,[appln_title]
    --  ,appln_abstract
      ,[appln_title_lg]
      ,[appln_abstract_lg]
  FROM [tls201_appln] a
 -- , [tls203_appln_abstr] b
  , [tls202_appln_title] c
  ,[tls211_pat_publn] d
  where publn_auth = 'EP'
  and publn_nr in ( '        1000000'
                   , '        1000001'
                   , '        1000002'
                   , '        1000003'
                   , '        1000004'
                   )
  and a.appln_id = d.appln_id
  --and a.appln_id = b.appln_id
  and a.appln_id = c.appln_id
  
  order by appln_id
GO

