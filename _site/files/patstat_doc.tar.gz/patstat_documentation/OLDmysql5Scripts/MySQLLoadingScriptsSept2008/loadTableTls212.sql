-- This runs a set of scripts to load a database table
--
--
-- Version March2008    Created by Tony Teculescu    on 04/03/2008    
--

alter table TLS212_CITATION disable keys;
load data local infile '<enter path of unzipped files here>\\tls212_part01.txt' into table TLS212_CITATION fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls212_part02.txt' into table TLS212_CITATION fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls212_part03.txt' into table TLS212_CITATION fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls212_part04.txt' into table TLS212_CITATION fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
load data local infile '<enter path of unzipped files here>\\tls212_part05.txt' into table TLS212_CITATION fields terminated by ',' optionally enclosed by '"' lines terminated by '\r\n' ignore 1 lines;
alter table TLS212_CITATION enable keys;
