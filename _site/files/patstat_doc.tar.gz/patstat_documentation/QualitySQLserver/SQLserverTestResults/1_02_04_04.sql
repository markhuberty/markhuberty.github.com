use patstatoct2011 
go
  SELECT
      appln_auth
     ,appln_nr
     ,person_name
     ,person_address
     ,a.appln_id
   FROM
   [TLS201_APPLN ] a
  ,[TLS206_person ] b
  ,[TLS207_pers_appln ] c
  where internat_appln_id = 0
  and   appln_auth = 'EP'
  and person_ctry_code = 'ES'
  and b.person_id = c.person_id
  and a.appln_id = c.appln_id
  and   invt_seq_nr > 0
  and a.appln_filing_date between '2000-01-01' and '2000-01-31'

order by person_name, person_address
   ;
                                                
                                                
                    use patstatapril2011
go
  SELECT
      appln_auth
     ,appln_nr
     ,person_name
     ,person_address
     ,a.appln_id
   FROM
   [TLS201_APPLN ] a
  ,[TLS206_person ] b
  ,[TLS207_pers_appln ] c
  where internat_appln_id = 0
  and   appln_auth = 'EP'
  and person_ctry_code = 'ES'
  and b.person_id = c.person_id
  and a.appln_id = c.appln_id
  and   invt_seq_nr > 0
  and a.appln_filing_date between '2000-01-01' and '2000-01-31'

order by person_name, person_address
   ;
                                                
                                                
                    